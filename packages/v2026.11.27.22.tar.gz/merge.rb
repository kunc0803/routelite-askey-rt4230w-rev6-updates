# 合并面板业务段与固定 DNS 策略；保留 OpenClash 的端口、认证和兼容性设置。
require 'yaml'
if ARGV[0] == '--install-hook'
  base = ENV.fetch('PANEL_DIR', '/etc/clashpanel')
  oc = ENV.fetch('OC_DIR', '/etc/openclash')
  path = oc + '/custom/openclash_custom_overwrite.sh'
  abort 'missing OpenClash custom directory' unless File.directory?(File.dirname(path))
  text = File.exist?(path) ? File.read(path) : "#!/bin/sh\nexit 0\n"
  marker = '# BEGIN CLASHPANEL FIXED DNS'
  text = text.sub(/# BEGIN CLASHPANEL FIXED DNS\n.*?# END CLASHPANEL FIXED DNS\n/m, '')
  begin
    block = "#{marker}\nif [ \"$(uci -q get openclash.config.config_path)\" = \"#{oc}/config/panel.yaml\" ] && [ -f \"#{base}/merge.rb\" ]; then\n  if [ -f \"#{base}/ipv4-only.sh\" ]; then PANEL_DIR=\"#{base}\" sh \"#{base}/ipv4-only.sh\" || exit 1; fi\n  ruby \"#{base}/merge.rb\" \"#{oc}/config/panel.yaml\" \"$1\" \"$1\" dns-only || exit 1\nfi\n# END CLASHPANEL FIXED DNS\n"
    pos = text.index(/^exit 0\s*$/)
    text = pos ? text[0...pos] + block + text[pos..-1] : text + "\n" + block
    File.write(path + '.panel-new', text)
    File.chmod(0755, path + '.panel-new')
    File.rename(path + '.panel-new', path)
  end
  exit
end
raw = YAML.load_file(ARGV[0])
cur = YAML.load_file(ARGV[1])
observed = Marshal.load(Marshal.dump(cur)) if ARGV[3] == 'compare'
abort('bad input') unless raw.is_a?(Hash) && cur.is_a?(Hash) && raw['proxy-groups'] && raw['rules']
unless ARGV[3] == 'dns-only'
  %w[proxies proxy-providers proxy-groups rules].each do |key|
    if raw.key?(key) && !(raw[key].respond_to?(:empty?) && raw[key].empty? && key == 'proxy-providers')
      cur[key] = raw[key]
    else
      cur.delete(key)
    end
  end
end
if raw['dns'].is_a?(Hash)
  dns = cur['dns'].is_a?(Hash) ? cur['dns'].dup : {}
  # 不保留任何全局 fallback、系统/直连解析器和旧策略，防止旧设置使海外查询回退国内。
  %w[fallback fallback-filter direct-nameserver direct-nameserver-follow-policy proxy-server-nameserver-policy nameserver-policy].each { |key| dns.delete(key) }
  cur['dns'] = dns.merge(raw['dns'])
  providers = cur['rule-providers'].is_a?(Hash) ? cur['rule-providers'].dup : {}
  providers.delete_if { |key, _| key.start_with?('panel-dns-') }
  providers.merge!(raw.fetch('rule-providers', {}))
  cur['rule-providers'] = providers unless providers.empty?
  cur.delete('rule-providers') if providers.empty?
end
# 内存优化（256MB 机型）：设备已有 oc-cn-domain.mrs 时，用它替换 GEOSITE,cn / geosite:cn，
# 避免 Mihomo 把整份 GeoSite.dat（约 11MB）解析进内存；文件不存在则保持原规则不变。
mrs = ENV.fetch('OC_DIR', '/etc/openclash') + '/rule_provider/oc-cn-domain.mrs'
if File.size?(mrs).to_i > 100_000
  swap = lambda { |line| line.is_a?(String) && line =~ /\AGEOSITE,cn(,|\z)/i ? line.sub(/\AGEOSITE,cn/i, 'RULE-SET,oc-cn-domain') : line }
  used = false
  if cur['rules'].is_a?(Array)
    cur['rules'] = cur['rules'].map { |l| n = swap.call(l); used ||= n != l; n }
  end
  if cur['sub-rules'].is_a?(Hash)
    cur['sub-rules'] = cur['sub-rules'].transform_values do |list|
      list.is_a?(Array) ? list.map { |l| n = swap.call(l); used ||= n != l; n } : list
    end
  end
  if cur['dns'].is_a?(Hash) && cur['dns']['nameserver-policy'].is_a?(Hash) && cur['dns']['nameserver-policy'].key?('geosite:cn')
    cur['dns']['nameserver-policy'] = cur['dns']['nameserver-policy'].each_with_object({}) { |(k, v), h| h[k == 'geosite:cn' ? 'rule-set:oc-cn-domain' : k] = v }
    used = true
  end
  if used
    cur['rule-providers'] = {} unless cur['rule-providers'].is_a?(Hash)
    cur['rule-providers']['oc-cn-domain'] ||= { 'type' => 'file', 'behavior' => 'domain', 'format' => 'mrs', 'path' => './rule_provider/oc-cn-domain.mrs' }
  end
end
if ARGV[3] == 'compare'
  puts %w[proxies proxy-providers proxy-groups rules dns rule-providers].any? { |key| cur[key] != observed[key] }
else
  File.write(ARGV[2], YAML.dump(cur))
end
