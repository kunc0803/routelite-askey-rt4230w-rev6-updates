# One-shot editor for existing 2.4/5 GHz APs. No network or daemon creation.
require 'json'
module Wifi24
  def self.run(*args)
    result=IO.popen(args,err:File::NULL,&:read)
    raise 'wifi24_save_failed' unless $?.success?
    # The router has no UTF-8 locale; SSIDs may be Chinese, so read uci output as UTF-8.
    result.force_encoding(Encoding::UTF_8).strip
  end
  def self.get(key)
    IO.popen(['uci','-q','get',key],err:File::NULL,&:read).force_encoding(Encoding::UTF_8).sub(/\r?\n\z/,'')
  end
  GUEST='routelite_guest'
  def self.guest?
    ENV['WIFI_IFACE'].to_s==GUEST
  end
  def self.target
    # The guest Wi-Fi is addressed by name; it is never picked as the main 5GHz or IoT AP.
    if guest?
      raise 'wifi24_unavailable' unless get("wireless.#{GUEST}")=='wifi-iface' && get("wireless.#{GUEST}.mode")=='ap'
      radio=get("wireless.#{GUEST}.device")
      raise 'wifi24_unavailable' unless radio.match?(/\A[A-Za-z0-9_-]+\z/) && get("wireless.#{radio}")=='wifi-device'
      return [radio,"wireless.#{GUEST}"]
    end
    text=run('uci','-q','show','wireless')
    radios=text.lines.map{|line| line[/\Awireless\.([^=]+)=wifi-device\s*$/,1]}.compact
    band=ENV.fetch('WIFI_BAND','2g')
    raise 'wifi24_unavailable' unless %w[2g 5g].include?(band)
    legacy=band=='2g' ? '11g' : '11a'
    radio=radios.find{|r| get("wireless.#{r}.band")==band || (get("wireless.#{r}.band").empty? && get("wireless.#{r}.hwmode")==legacy)}
    raise 'wifi24_unavailable' unless radio && radio.match?(/\A[A-Za-z0-9_-]+\z/)
    ifaces=text.lines.map{|line|line[/\Awireless\.([^=]+)=wifi-iface\s*$/,1]}.compact
    candidates=ifaces.select{|i|i!=GUEST && get("wireless.#{i}.device")==radio && get("wireless.#{i}.mode")=='ap'}
    preferred=band=='2g' ? 'routelite_iot' : 'lan'
    iface=candidates.find{|i|get("wireless.#{i}.network").split.include?(preferred)} || candidates.first
    raise 'wifi24_unavailable' unless iface
    [radio,"wireless.#{iface}"]
  end
  # The guest Wi-Fi must not share a name with any other Wi-Fi (phones would mix them up).
  def self.same_name?(key,ssid)
    return false if ssid.empty?
    text=run('uci','-q','show','wireless')
    others=text.lines.map{|line|line[/\Awireless\.([^=]+)=wifi-iface\s*$/,1]}.compact.reject{|i|"wireless.#{i}"==key}
    others=others.select{|i|i==GUEST} unless guest?
    others.any?{|i|get("wireless.#{i}.mode")=='ap' && get("wireless.#{i}.ssid")==ssid}
  end
  def self.enabled(radio,key)
    get(key+'.disabled')!='1' && get("wireless.#{radio}.disabled")!='1'
  end
  def self.read
    radio,key=target
    {'ok'=>true,'ssid'=>get(key+'.ssid'),'radio'=>radio,'has_password'=>!get(key+'.key').empty?,'enabled'=>enabled(radio,key)}
  end
  def self.save(data)
    radio,key=target
    raise 'wifi24_bad_enabled' if data.key?('enabled') && data['enabled']!=true && data['enabled']!=false
    desired=data.key?('enabled') ? data['enabled'] : enabled(radio,key)
    ssid=data.key?('ssid') ? data['ssid'] : get(key+'.ssid')
    password=data.key?('password') ? data['password'] : ''
    raise 'wifi24_bad_name' unless ssid.is_a?(String) && ssid.valid_encoding? && ((1..32).include?(ssid.bytesize) || (ssid.empty? && guest? && !desired)) && !ssid.match?(/[\x00-\x1f\x7f]/)
    raise 'wifi24_bad_password' unless password.is_a?(String) && (password.empty? || ((8..63).include?(password.bytesize) && !password.match?(/[\x00-\x1f\x7f]/)) || password.match?(/\A[0-9a-fA-F]{64}\z/))
    raise 'wifi24_pending_wireless' unless run('uci','changes','wireless').empty?
    if guest? && desired
      # Guests always need their own name and a password before the Wi-Fi can go on.
      raise 'wifi24_bad_name' if ssid.empty?
      raise 'wifi24_need_password' if password.empty? && get(key+'.key').empty?
    end
    raise 'wifi24_same_name' if same_name?(key,ssid)
    changed=ssid!=get(key+'.ssid') || (!password.empty? && password!=get(key+'.key')) || desired!=enabled(radio,key)
    return {'ok'=>true,'changed'=>false,'radio'=>radio,'ssid'=>ssid,'enabled'=>desired} unless changed
    config=ENV.fetch('WIRELESS_CONFIG','/etc/config/wireless')
    root=ENV.fetch('PANEL_DIR','/etc/clashpanel')
    backup=root+"/backup/wifi-#{ENV.fetch('WIFI_BAND','2g')}-#{Time.now.to_i}-#{Process.pid}.conf"
    File.binwrite(backup,File.binread(config)); File.chmod(0600,backup)
    begin
      if data.key?('enabled') && desired!=enabled(radio,key)
        run('uci','set',key+'.disabled='+(desired ? '0' : '1'))
        run('uci','set',"wireless.#{radio}.disabled=0") if desired && get("wireless.#{radio}.disabled")=='1'
      end
      run('uci','set',key+'.ssid='+ssid) if ssid!=get(key+'.ssid')
      unless password.empty?
        run('uci','set',key+'.key='+password)
        run('uci','set',key+'.encryption=psk2') if get(key+'.encryption')=='none' || (guest? && get(key+'.encryption')!='psk2')
      end
      run('uci','commit','wireless')
    rescue StandardError
      File.binwrite(config,File.binread(backup))
      IO.popen(['uci','-q','revert','wireless'],err:File::NULL,&:read)
      raise 'wifi24_save_failed'
    end
    {'ok'=>true,'changed'=>true,'radio'=>radio,'ssid'=>ssid,'enabled'=>desired}
  end
end
if __FILE__==$0
  begin
    result=ARGV[0]=='get' ? Wifi24.read : Wifi24.save(JSON.parse(File.read(ARGV.fetch(1))))
    puts JSON.generate(result)
  rescue StandardError => e
    known=%w[wifi24_unavailable wifi24_save_failed wifi24_bad_name wifi24_bad_password wifi24_bad_enabled wifi24_pending_wireless wifi24_need_password wifi24_same_name]
    puts JSON.generate({'ok'=>false,'error'=>known.include?(e.message) ? e.message : 'wifi24_save_failed'})
  end
end
