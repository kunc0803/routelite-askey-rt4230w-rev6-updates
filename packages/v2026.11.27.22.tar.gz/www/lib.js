/* 节点解析 + OpenClash(mihomo) 配置生成。浏览器和 Node 共用，无依赖。 */
(function (root) {
  'use strict';

  var SWITCH_TOLERANCE_MS = 100;
  var HEALTH_URL = 'http://www.gstatic.com/generate_204';
  var RESERVED = ['PROXY', 'AUTO', 'DIRECT', 'REJECT', 'GLOBAL', 'PANEL-BLOCKED-EXIT'];
  var CHECK_PREFIX = 'PANEL-CHECK@';
  var SS_CIPHERS = new Set([
    'aes-128-ctr', 'aes-192-ctr', 'aes-256-ctr', 'aes-128-cfb', 'aes-192-cfb', 'aes-256-cfb',
    'aes-128-gcm', 'aes-192-gcm', 'aes-256-gcm', 'aes-128-ccm', 'aes-192-ccm', 'aes-256-ccm',
    'aes-128-gcm-siv', 'aes-256-gcm-siv', 'chacha20-ietf', 'chacha20', 'xchacha20',
    'chacha20-ietf-poly1305', 'xchacha20-ietf-poly1305', 'chacha8-ietf-poly1305', 'xchacha8-ietf-poly1305',
    '2022-blake3-aes-128-gcm', '2022-blake3-aes-256-gcm', '2022-blake3-chacha20-poly1305',
    'lea-128-gcm', 'lea-192-gcm', 'lea-256-gcm', 'rabbit128-poly1305',
    'aegis-128l', 'aegis-256', 'aez-384', 'deoxys-ii-256-128', 'rc4-md5', 'none'
  ]);

  function stripBrackets(h) { return h.replace(/^\[|\]$/g, ''); }
  function isIPv4(s) { return /^(\d{1,3}\.){3}\d{1,3}$/.test(s); }
  function isIPv6(s) { return s.indexOf(':') >= 0 && /^[0-9a-f:.]+$/i.test(s); }

  /* ---------- 名字：节点/出口/订阅里的名字不能重复，也不能用保留名 ---------- */
  function nameTaken(state, name) {
    if (RESERVED.indexOf(name) >= 0 || name.indexOf(CHECK_PREFIX) === 0) return true;
    return (state.nodes || []).concat(state.exits || []).some(function (x) { return x.name === name; });
  }
  function uniqueName(state, name) {
    if (name.indexOf(CHECK_PREFIX) === 0) name = '节点 ' + name;
    if (!nameTaken(state, name)) return name;
    for (var i = 2; ; i++) if (!nameTaken(state, name + ' ' + i)) return name + ' ' + i;
  }

  /* ---------- vless 单节点 ---------- */
  function parseVless(link) {
    link = String(link || '').trim();
    if (!/^vless:\/\//i.test(link)) throw new Error('不是 vless:// 开头的链接');
    var u;
    try { u = new URL(link); }
    catch (e) { throw new Error('链接格式不对'); }
    var q = function (k) { return u.searchParams.get(k) || ''; };
    var server = parseServer(u.hostname);
    var port = parsePort(u.port);
    var uuid = decodeURIComponent(u.username);
    if (!validUuid(uuid)) throw new Error('UUID 格式不对');
    var enc = q('encryption');
    if (enc && enc !== 'none') throw new Error('暂不支持 encryption=' + enc);

    var net = q('type') || 'tcp';
    if (net === 'raw') net = 'tcp';
    if (['tcp', 'ws', 'grpc', 'h2', 'http', 'httpupgrade'].indexOf(net) < 0) throw new Error('暂不支持传输方式 ' + net);

    var name = '';
    try { name = decodeURIComponent((u.hash || '').replace(/^#/, '')); } catch (e) { name = (u.hash || '').replace(/^#/, ''); }
    name = name.trim().slice(0, 40) || (server + ':' + port);

    var sec = q('security');
    var p = { name: name, type: 'vless', server: server, port: port, uuid: uuid, udp: true };
    if (q('flow')) p.flow = q('flow');

    if (sec === 'tls' || sec === 'reality') {
      p.tls = true;
      var sni = q('sni') || q('peer');
      if (sni) p.servername = sni;
      var fp = q('fp');
      if (fp) p['client-fingerprint'] = fp;
      if (q('alpn')) p.alpn = q('alpn').split(',');
      if (q('allowInsecure') === '1' || q('insecure') === '1') p['skip-cert-verify'] = true;
    } else if (sec && sec !== 'none') {
      throw new Error('暂不支持 security=' + sec);
    }
    if (sec === 'reality') {
      if (!q('pbk')) throw new Error('reality 缺少 pbk（公钥）');
      if (!p['client-fingerprint']) p['client-fingerprint'] = 'chrome';
      p['reality-opts'] = { 'public-key': q('pbk'), 'short-id': q('sid') };
    }

    applyTransport(p, net, q('path'), q('host'), q('serviceName'));
    return p;
  }

  function parseNodeLink(link) {
    link = String(link || '').trim();
    var protocol = link.split('://', 1)[0].toLowerCase();
    if (protocol === 'vless') return parseVless(link);
    if (protocol === 'ss') return parseShadowsocks(link);
    if (protocol === 'trojan') return parseTrojan(link);
    if (protocol === 'vmess') return parseVmess(link);
    if (['hysteria2', 'hy2', 'hysteria', 'tuic', 'anytls', 'socks', 'socks5', 'socks5h', 'http-proxy', 'https-proxy'].includes(protocol)) return parseExtendedLink(link, protocol);
    if (protocol === 'ssr') return parseSSR(link);
    if (protocol === 'http' || protocol === 'https') throw new Error('请使用「导入链接」添加订阅');
    throw new Error('不支持此链接格式；请查看输入框中的协议列表');
  }

  function shareUrl(link) {
    try {
      return new URL(link);
    } catch (error) {
      throw new Error('链接格式不对');
    }
  }

  function shareParam(url) {
    return function (key) { return url.searchParams.get(key) || ''; };
  }

  function decodeBase64(value) {
    try {
      var raw = atob(value.replace(/-/g, '+').replace(/_/g, '/'));
      return new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(raw, function (ch) { return ch.charCodeAt(0); }));
    } catch (error) {
      throw new Error('节点链接的 Base64 内容无效');
    }
  }

  function shareName(name, server, port) {
    return String(name || '').trim().slice(0, 40) || server + ':' + port;
  }

  function urlName(url) {
    return decodeURIComponent(url.hash.slice(1));
  }

  function parseServer(server) {
    var raw = decodeURIComponent(String(server || '')).trim();
    if (isIPv6(raw)) raw = '[' + raw + ']';
    if (!raw || /[\s\/\\?#@]/.test(raw)) throw new Error('服务器地址无效');
    if (raw.indexOf(':') >= 0 && raw[0] !== '[') throw new Error('服务器地址不应包含端口');
    try {
      var url = new URL('http://' + raw);
      if (url.port || !url.hostname || (raw[0] === '[' && !raw.endsWith(']'))) throw new Error();
      return stripBrackets(url.hostname);
    } catch (error) {
      throw new Error('服务器地址无效');
    }
  }

  function parsePort(port) {
    if (!/^\d+$/.test(String(port)) || +port < 1 || +port > 65535) throw new Error('端口应为 1–65535');
    return Number(port);
  }

  function validUuid(uuid) {
    return typeof uuid === 'string' && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(uuid);
  }

  function listOf(value) {
    return String(value || '').split(',').map(function (item) { return item.trim(); }).filter(Boolean);
  }

  function applyTransport(p, network, path, host, service) {
    p.network = network;
    if (network === 'ws' || network === 'httpupgrade') {
      p['ws-opts'] = { path: path || '/' };
      if (host) p['ws-opts'].headers = { Host: host };
      if (network === 'httpupgrade') {
        p.network = 'ws';
        p['ws-opts']['v2ray-http-upgrade'] = true;
      }
    } else if (network === 'grpc') {
      p['grpc-opts'] = { 'grpc-service-name': service || path || '' };
    } else if (network === 'h2') {
      p['h2-opts'] = { path: path || '/' };
      if (host) p['h2-opts'].host = listOf(host);
    } else if (network === 'http') {
      p['http-opts'] = { method: 'GET', path: [path || '/'] };
      if (host) p['http-opts'].headers = { Host: listOf(host) };
    }
  }

  function readTls(p, get, sniKey, security) {
    if (security !== 'tls' && security !== 'reality') throw new Error('暂不支持这种传输层安全设置');
    p.tls = true;
    var sni = get('sni') || get('peer');
    if (sni) p[sniKey] = sni;
    if (get('fp')) p['client-fingerprint'] = get('fp');
    var alpn = listOf(get('alpn'));
    if (alpn.length) p.alpn = alpn;
    if (/^(1|true)$/i.test(get('allowInsecure') || get('insecure'))) p['skip-cert-verify'] = true;
    if (get('vcn')) p['name-cert-verify'] = get('vcn');
    if (get('pcs')) p.fingerprint = get('pcs');
    if (security === 'reality') {
      if (!get('pbk')) throw new Error('REALITY 缺少公钥');
      p['client-fingerprint'] = p['client-fingerprint'] || 'chrome';
      p['reality-opts'] = { 'public-key': get('pbk'), 'short-id': get('sid') };
    }
  }

  function parseShadowsocks(link) {
    var parts = link.slice(5).match(/^([^?#]*)(\?[^#]*)?(#.*)?$/);
    if (!parts || !parts[1]) throw new Error('Shadowsocks 链接格式不对');
    var body = parts[1];
    var legacy = body.indexOf('@') < 0;
    if (legacy) body = decodeBase64(body);
    var at = body.lastIndexOf('@');
    if (at <= 0) throw new Error('Shadowsocks 链接缺少认证信息或服务器');
    var credentials = body.slice(0, at);
    if (!legacy) {
      var decoded = decodeURIComponent(credentials);
      credentials = credentials.indexOf(':') >= 0 ? decoded : decodeBase64(decoded);
    }
    var sep = credentials.indexOf(':');
    if (sep <= 0) throw new Error('Shadowsocks 链接缺少加密方式');
    var url = shareUrl('ss://' + body.slice(at + 1) + (parts[2] || '') + (parts[3] || ''));
    if (url.pathname && url.pathname !== '/') throw new Error('Shadowsocks 服务器格式不正确');
    var server = parseServer(url.hostname), port = parsePort(url.port);
    var cipher = credentials.slice(0, sep).toLowerCase();
    if (!SS_CIPHERS.has(cipher)) {
      throw new Error('暂不支持这种 Shadowsocks 加密方式');
    }
    var password = credentials.slice(sep + 1);
    if (!password && cipher !== 'none') throw new Error('Shadowsocks 链接缺少密码');
    if (cipher.indexOf('2022-') === 0) {
      var expectedBytes = cipher === '2022-blake3-aes-128-gcm' ? 16 : 32;
      try {
        if (!password.split(':').every(function (key) { return atob(key).length === expectedBytes; })) throw new Error();
      } catch (error) {
        throw new Error('Shadowsocks 2022 密钥格式或长度不正确');
      }
    }
    var p = { name: shareName(urlName(url), server, port), type: 'ss', server: server, port: port,
      cipher: cipher, password: password, udp: true };
    var plugin = url.searchParams.get('plugin');
    if (plugin) applySSPlugin(p, plugin);
    return p;
  }

  function applySSPlugin(p, raw) {
    var pieces = raw.match(/(?:\\.|[^\\;])+/g) || [];
    var name = pieces.shift();
    var values = Object.create(null);
    pieces.forEach(function (piece) {
      var eq = piece.indexOf('=');
      var key = eq < 0 ? piece : piece.slice(0, eq);
      values[key] = eq < 0 ? true : piece.slice(eq + 1).replace(/\\([\\;=:])/g, '$1');
    });
    var keys = Object.keys(values);
    if (/^(obfs|obfs-local|simple-obfs)$/.test(name) && keys.every(function (key) { return ['obfs', 'obfs-host'].includes(key); })) {
      if (!/^(http|tls)$/.test(values.obfs)) throw new Error('Shadowsocks obfs 插件缺少 http 或 tls 模式');
      p.plugin = 'obfs';
      p['plugin-opts'] = { mode: values.obfs };
      if (typeof values['obfs-host'] === 'string') p['plugin-opts'].host = values['obfs-host'];
    } else if (name === 'v2ray-plugin' && keys.every(function (key) { return ['mode', 'host', 'path', 'tls', 'mux'].includes(key); })) {
      if ((values.mode && values.mode !== 'websocket') || ('mux' in values && !/^(0|1|true|false)$/i.test(values.mux))) {
        throw new Error('暂不支持这种 v2ray-plugin 模式或复用设置');
      }
      p.plugin = 'v2ray-plugin';
      p['plugin-opts'] = { mode: 'websocket' };
      ['host', 'path'].forEach(function (key) {
        if (typeof values[key] === 'string') p['plugin-opts'][key] = values[key];
      });
      if ('tls' in values) p['plugin-opts'].tls = /^(true|1)$/i.test(values.tls);
      if ('mux' in values) p['plugin-opts'].mux = /^(true|1)$/i.test(values.mux);
    } else {
      throw new Error('暂不支持这个 Shadowsocks 插件或它的参数');
    }
  }

  function parseTrojan(link) {
    var url = shareUrl(link), get = shareParam(url);
    var server = parseServer(url.hostname), port = parsePort(url.port || 443);
    var password = decodeURIComponent(url.username + (url.password ? ':' + url.password : ''));
    if (!password) throw new Error('Trojan 链接缺少密码');
    if (get('encryption') && get('encryption') !== 'none') throw new Error('暂不支持这种 Trojan 扩展加密');
    var network = get('type') || 'tcp';
    if (network === 'raw') network = 'tcp';
    if (!['tcp', 'ws', 'grpc'].includes(network)) throw new Error('暂不支持这种 Trojan 传输方式');
    if (network === 'grpc' && (get('authority') || (get('mode') && get('mode') !== 'gun'))) throw new Error('暂不支持这种 gRPC 设置');
    var p = { name: shareName(urlName(url), server, port), type: 'trojan', server: server, port: port, password: password, udp: true };
    readTls(p, get, 'sni', get('security') || 'tls');
    delete p.tls; // Trojan 内核出站本身使用 TLS。
    applyTransport(p, network, get('path'), get('host'), get('serviceName'));
    return p;
  }

  function parseVmess(link) {
    var json, url, get;
    if (link.slice(8).split(/[?#]/, 1)[0].indexOf('@') >= 0) {
      url = shareUrl(link);
      get = shareParam(url);
      json = {
        ps: urlName(url), add: url.hostname, port: url.port, id: decodeURIComponent(url.username),
        aid: get('alterId'), scy: get('encryption'), net: get('type'), type: get('headerType'),
        path: get('path'), host: get('host'), tls: get('security')
      };
    } else {
      try { json = JSON.parse(decodeBase64(link.slice(8))); }
      catch (error) { throw new Error('VMess 链接需要有效的 Base64 JSON 节点'); }
      if (!json || typeof json !== 'object' || Array.isArray(json)) throw new Error('VMess 配置格式无效');
      get = function (key) { return typeof json[key] === 'string' || typeof json[key] === 'number' ? String(json[key]) : ''; };
    }
    var server = parseServer(json.add), port = parsePort(json.port);
    if (!validUuid(json.id)) throw new Error('VMess UUID 格式不对');
    var alterId = json.aid === undefined || json.aid === '' ? 0 : json.aid;
    if (!/^\d+$/.test(String(alterId)) || +alterId > 65535) throw new Error('VMess alterId 无效');
    var cipher = String(json.scy || 'auto').toLowerCase();
    if (!['auto', 'none', 'zero', 'aes-128-gcm', 'chacha20-poly1305'].includes(cipher)) throw new Error('暂不支持这种 VMess 加密方式');
    var network = String(json.net || 'tcp').toLowerCase();
    if (network === 'raw') network = 'tcp';
    var header = String(json.type || '').toLowerCase();
    if (!['tcp', 'ws', 'grpc', 'h2', 'http', 'httpupgrade'].includes(network) ||
        (header && !['none', 'http'].includes(header) && !(network === 'grpc' && header === 'gun'))) {
      throw new Error('暂不支持这种 VMess 传输方式或伪装类型');
    }
    if (network === 'grpc' && (get('authority') || (get('mode') && get('mode') !== 'gun'))) throw new Error('暂不支持这种 gRPC 设置');
    if (header === 'http' && network === 'tcp') network = 'http';
    else if (network === 'http' && header !== 'http') network = 'h2';
    var p = { name: shareName(json.ps, server, port), type: 'vmess', server: server, port: port, uuid: json.id,
      alterId: Number(alterId), cipher: cipher, udp: true };
    var security = String(json.tls || '').toLowerCase();
    if (security && security !== 'none' && security !== 'false' && security !== '0') readTls(p, get, 'servername', security);
    applyTransport(p, network, json.path, json.host, get('serviceName'));
    return p;
  }

  // Share links are parsed only in the browser; no extra daemon or library.
  function checkShareParams(url, allowed) {
    url.searchParams.forEach(function (_, key) {
      if (!allowed.includes(key)) throw new Error('暂不支持链接参数：' + key + '，请使用兼容的 Clash 订阅');
    });
    if (url.pathname && url.pathname !== '/') throw new Error('节点链接不应包含路径');
  }
  function readShareTLS(p, get) {
    var sni = get('sni') || get('peer');
    if (sni) p.sni = sni;
    var insecure = get('insecure') || get('allowInsecure') || get('allow_insecure') || get('skip-cert-verify');
    if (insecure) {
      if (!/^(0|1|true|false)$/i.test(insecure)) throw new Error('证书校验参数无效');
      p['skip-cert-verify'] = /^(1|true)$/i.test(insecure);
    }
    if (get('alpn')) p.alpn = listOf(get('alpn'));
    if (get('fp')) p['client-fingerprint'] = get('fp');
    if (get('pinSHA256')) p.fingerprint = get('pinSHA256');
  }
  function parseExtendedLink(link, scheme) {
    var hopping = '';
    if (scheme === 'hy2' || scheme === 'hysteria2') {
      // WHATWG URL cannot parse a port range. Normalize only the authority port.
      link = link.replace(/^(hysteria2|hy2):\/\/([^/?#]+)(.*)$/i, function (_, proto, authority, rest) {
        var m = authority.match(/:([0-9]+(?:[-,][0-9]+)+)$/);
        if (!m) return _;
        hopping = m[1];
        hopping.split(',').forEach(function (part) {
          var ends = part.split('-');
          ends.forEach(parsePort);
          if (ends.length > 2 || (ends.length === 2 && +ends[0] > +ends[1])) throw new Error('跳跃端口范围无效');
        });
        return proto + '://' + authority.slice(0, -m[0].length) + ':' + hopping.split(/[-,]/)[0] + rest;
      });
    }
    var url = shareUrl(link), get = shareParam(url);
    var server = parseServer(url.hostname);
    var type = /^(hy2|hysteria2)$/.test(scheme) ? 'hysteria2' : /^socks/.test(scheme) ? 'socks5' : /-proxy$/.test(scheme) ? 'http' : scheme;
    var port = parsePort(url.port || (type === 'socks5' ? 1080 : scheme === 'http-proxy' ? 80 : 443));
    var p = { name: shareName(urlName(url), server, port), type: type, server: server, port: port };
    var tlsKeys = ['sni', 'peer', 'insecure', 'allowInsecure', 'allow_insecure', 'skip-cert-verify', 'alpn', 'fp', 'pinSHA256'];
    var user = decodeURIComponent(url.username), pass = decodeURIComponent(url.password);
    if (type === 'hysteria2' || type === 'anytls') {
      checkShareParams(url, tlsKeys.concat(type === 'hysteria2' ? ['obfs', 'obfs-password', 'up', 'down'] : []));
      p.password = user + (url.password ? ':' + pass : '');
      if (!p.password) throw new Error('节点链接缺少密码');
      p.udp = true;
      readShareTLS(p, get);
      if (type === 'hysteria2') {
        if (hopping) p.ports = hopping;
        if (get('obfs')) {
          if (get('obfs') !== 'salamander') throw new Error('当前仅支持 salamander 混淆');
          if (!get('obfs-password')) throw new Error('混淆缺少密码');
          p.obfs = get('obfs'); p['obfs-password'] = get('obfs-password');
        } else if (get('obfs-password')) throw new Error('混淆缺少类型');
        ['up', 'down'].forEach(function (key) {
          if (get(key)) { if (!/^[0-9]+(?:\.[0-9]+)?(?:\s*[KMG]?[bB]ps)?$/.test(get(key))) throw new Error('带宽参数无效'); p[key] = get(key); }
        });
      }
    } else if (type === 'tuic') {
      checkShareParams(url, tlsKeys.concat(['congestion_control', 'congestion-controller', 'udp_relay_mode', 'udp-relay-mode', 'disable_sni', 'disable-sni', 'reduce_rtt', 'reduce-rtt']));
      if (!user) throw new Error('TUIC 缺少认证信息');
      if (url.password) { if (!validUuid(user)) throw new Error('TUIC UUID 格式不对'); p.uuid = user; p.password = pass; }
      else p.token = user; // TUIC v4
      p.udp = true; readShareTLS(p, get);
      var cc = get('congestion_control') || get('congestion-controller');
      if (cc) { if (!['bbr', 'cubic', 'new_reno'].includes(cc)) throw new Error('TUIC 拥塞控制参数无效'); p['congestion-controller'] = cc; }
      var mode = get('udp_relay_mode') || get('udp-relay-mode');
      if (mode) { if (!['native', 'quic'].includes(mode)) throw new Error('TUIC UDP 模式无效'); p['udp-relay-mode'] = mode; }
      ['disable-sni', 'reduce-rtt'].forEach(function (key) {
        var v = get(key) || get(key.replace('-', '_'));
        if (v) { if (!/^(0|1|true|false)$/i.test(v)) throw new Error('TUIC 开关参数无效'); p[key] = /^(1|true)$/i.test(v); }
      });
    } else if (type === 'hysteria') {
      checkShareParams(url, tlsKeys.concat(['auth', 'obfs', 'protocol', 'up', 'down', 'upmbps', 'downmbps']));
      if (user || pass) throw new Error('Hysteria 1 认证请放在 auth 参数');
      if (get('auth')) p['auth-str'] = get('auth');
      p.protocol = get('protocol') || 'udp';
      if (!['udp', 'wechat-video', 'faketcp'].includes(p.protocol)) throw new Error('Hysteria 传输协议无效');
      p.up = get('up') || get('upmbps'); p.down = get('down') || get('downmbps');
      if (!p.up || !p.down) throw new Error('Hysteria 1 缺少 up/down 带宽参数');
      if (![p.up, p.down].every(function (v) { return /^[0-9]+(?:\.[0-9]+)?(?:\s*[KMG]?[bB]ps)?$/.test(v) && parseFloat(v) > 0; })) throw new Error('Hysteria 带宽参数无效');
      if (get('obfs')) p.obfs = get('obfs');
      readShareTLS(p, get);
    } else {
      checkShareParams(url, tlsKeys.concat(['tls', 'udp']));
      if (user && !url.password && type === 'socks5' && !user.includes(':')) {
        // Shadowrocket SOCKS credentials may use URL-safe Base64(user:password).
        try { var decoded = decodeBase64(user), colon = decoded.indexOf(':'); if (colon >= 0) { user = decoded.slice(0, colon); pass = decoded.slice(colon + 1); } } catch (_) {}
      }
      if (user) p.username = user;
      if (pass) p.password = pass;
      var tls = get('tls');
      if (tls && !/^(0|1|true|false)$/i.test(tls)) throw new Error('TLS 参数无效');
      if (scheme === 'https-proxy' || /^(1|true)$/i.test(tls)) { p.tls = true; readShareTLS(p, get); }
      else if (tlsKeys.some(function (key) { return get(key); })) throw new Error('TLS 参数需要开启 tls=1');
      if (type === 'socks5') {
        if (get('udp') && !/^(0|1|true|false)$/i.test(get('udp'))) throw new Error('UDP 参数无效');
        p.udp = !/^(0|false)$/i.test(get('udp'));
      } else if (get('udp')) throw new Error('HTTP 代理不支持 UDP');
    }
    return p;
  }
  function parseSSR(link) {
    var raw = decodeBase64(link.slice(6)), split = raw.indexOf('/?');
    var body = split < 0 ? raw : raw.slice(0, split);
    var m = body.match(/^(.*):(\d+):([^:]+):([^:]+):([^:]+):([^:]*)$/);
    if (!m) throw new Error('SSR 链接格式不对');
    var query = new URLSearchParams(split < 0 ? '' : raw.slice(split + 2));
    query.forEach(function (_, key) { if (!['remarks', 'group', 'obfsparam', 'protoparam', 'udpport', 'uot'].includes(key)) throw new Error('暂不支持 SSR 参数：' + key); });
    if ((query.get('udpport') && query.get('udpport') !== '0') || (query.get('uot') && query.get('uot') !== '0')) throw new Error('暂不支持 SSR 独立 UDP 端口或 UDP over TCP');
    if (!['origin', 'auth_sha1_v4', 'auth_aes128_md5', 'auth_aes128_sha1', 'auth_chain_a', 'auth_chain_b'].includes(m[3])) throw new Error('暂不支持这种 SSR 认证协议');
    if (!['plain', 'http_simple', 'http_post', 'random_head', 'tls1.2_ticket_auth', 'tls1.2_ticket_fastauth'].includes(m[5])) throw new Error('暂不支持这种 SSR 混淆');
    var server = parseServer(m[1]), port = parsePort(m[2]);
    var p = { name: shareName(query.get('remarks') ? decodeBase64(query.get('remarks')) : '', server, port),
      type: 'ssr', server: server, port: port, protocol: m[3], cipher: m[4], obfs: m[5], password: decodeBase64(m[6]), udp: true };
    if (!SS_CIPHERS.has(p.cipher) || !p.password) throw new Error('SSR 加密方式或密码无效');
    if (query.get('obfsparam')) p['obfs-param'] = decodeBase64(query.get('obfsparam'));
    if (query.get('protoparam')) p['protocol-param'] = decodeBase64(query.get('protoparam'));
    return p;
  }

  function isSubscriptionNodeExcluded(sub, name) {
    return Array.isArray(sub.excludedNodes) && sub.excludedNodes.indexOf(name)>=0;
  }
  function excludeSubscriptionNode(sub, name) {
    if(typeof name!=='string' || !name)throw new Error('节点名称无效');
    if(!Array.isArray(sub.excludedNodes))sub.excludedNodes=[];
    if(!isSubscriptionNodeExcluded(sub,name))sub.excludedNodes.push(name);
  }
  function excludedNodePattern(sub) {
    var names=Array.isArray(sub.excludedNodes)?sub.excludedNodes.filter(function(n){return typeof n==='string' && n;}):[];
    if(!names.length)return '';
    return '^(?:'+names.map(function(n){return n.replace(/[.*+?^${}()|[\]\\]/g,'\\$&').replace(/`/g,'\\x60');}).join('|')+')$';
  }

  /* ---------- 订阅（机场）：交给内核的 proxy-provider 下载、解析、定时更新 ---------- */
  var SUB_HOURS = [0, 1, 6, 12, 24, 72, 168]; // 0 = 关闭自动更新
  function makeSub(name, url, hours) {
    name = String(name || '').trim().slice(0, 30);
    url = String(url || '').trim();
    hours = Number(hours);
    if (!name) throw new Error('请填订阅名称');
    if (!/^https?:\/\/[^\s"'<>\\]+$/i.test(url)) throw new Error('订阅链接要以 http:// 或 https:// 开头');
    if (SUB_HOURS.indexOf(hours) < 0) throw new Error('更新频率不对');
    var id = 's' + Math.random().toString(36).slice(2, 8);
    return { id: id, name: name, url: url, hours: hours };
  }

  // One entry point: HTTP(S) -> subscription; share URI -> local node.
  // Parsing is local and performs no request. It never changes the current route.
  function importLinks(state, text, options) {
    options = options || {};
    var result = { nodes: [], subs: [], errors: [], skipped: 0 };
    var used = { nodes: (state.nodes || []).slice(), subs: (state.subs || []).slice(), exits: state.exits || [] };
    function canonical(value) {
      if (Array.isArray(value)) return value.map(canonical);
      if (value && typeof value === 'object') { var out = {}; Object.keys(value).sort().forEach(function (k) { if (k !== 'name' && k !== '_link') out[k] = canonical(value[k]); }); return out; }
      return value;
    }
    function fingerprint(node) { return JSON.stringify(canonical(node)); }
    var seenNodes = new Set(used.nodes.map(fingerprint));
    function subIdentity(value) { var u = new URL(value); u.hash = ''; return u.href; }
    var seenSubs = new Set(used.subs.map(function (s) { try { return subIdentity(s.url); } catch(e) { return s.url; } }));
    var lines = String(text || '').split(/\r?\n/).map(function (line, i) { return { text: line.trim(), line: i + 1 }; }).filter(function (row) { return row.text; });
    if (lines.length > 200) throw new Error('一次最多导入 200 条链接，请分批添加');
    if (!lines.length) throw new Error('请先粘贴节点链接或订阅链接');
    lines.forEach(function (row) {
      try {
        if (/^https?:\/\//i.test(row.text)) {
          var url = shareUrl(row.text);
          if (!url.hostname || /[\s"'<>\\]/.test(row.text)) throw new Error('订阅链接格式不对');
          var identity = subIdentity(row.text);
          if (seenSubs.has(identity)) { result.skipped++; return; }
          var label = '';
          try { label = decodeURIComponent(url.hash.slice(1)); } catch(e) {}
          label = String(options.name || '').trim() || label || url.hostname;
          label=label.slice(0,30);
          var base = label, n = 2;
          while (used.subs.some(function (s) { return s.name === label; })) {var suffix=' '+n++;label=base.slice(0,30-suffix.length)+suffix;}
          var sub = makeSub(label, identity, options.hours === undefined ? 24 : options.hours);
          while (used.subs.some(function(s) { return s.id === sub.id; })) sub.id = 's' + Math.random().toString(36).slice(2, 10);
          used.subs.push(sub); seenSubs.add(identity); result.subs.push(sub);
        } else {
          var node = parseNodeLink(row.text), fp = fingerprint(node);
          if (seenNodes.has(fp)) { result.skipped++; return; }
          node.name = uniqueName(used, node.name); node._link = row.text; used.nodes.push(node); seenNodes.add(fp); result.nodes.push(node);
        }
      } catch (e) { result.errors.push({ line: row.line, input: row.text, message: e.message }); }
    });
    return result;
  }

  var BLOCKED_EXIT = 'PANEL-BLOCKED-EXIT';
  function exitReferences(state, name) {
    return { defaultExit: state.exit === name, nodes: Object.keys(state.nodeExits || {}).filter(function(k){return state.nodeExits[k]===name;}).length,
      subscriptions:(state.subs||[]).filter(function(s){return s.exit===name;}).length,
      rules:(state.rules||[]).filter(function(r){return r.exit && r.exit.mode==='fixed' && r.exit.name===name;}).length };
  }
  function removeExit(state, name, resolution) {
    resolution=resolution || {mode:'block'};
    var index=(state.exits||[]).findIndex(function(e){return e.name===name;});
    if(index<0)throw new Error('这个家宽已被删除，请刷新后核对');
    if(['block','off','replace'].indexOf(resolution.mode)<0)throw new Error('请选择相关线路的处理方式');
    if(resolution.mode==='replace' && !(state.exits||[]).some(function(e){return e.name===resolution.name && e.name!==name;}))throw new Error('替代家宽不存在，请重新选择');
    var refs=exitReferences(state,name),target=resolution.mode==='replace'?resolution.name:resolution.mode==='off'?'':BLOCKED_EXIT;
    if(state.exit===name)state.exit=target;
    Object.keys(state.nodeExits||{}).forEach(function(k){if(state.nodeExits[k]===name){if(target)state.nodeExits[k]=target;else delete state.nodeExits[k];}});
    (state.subs||[]).forEach(function(s){if(s.exit===name){if(target)s.exit=target;else delete s.exit;}});
    (state.rules||[]).forEach(function(r){if(r.exit && r.exit.mode==='fixed' && r.exit.name===name)r.exit=target?{mode:'fixed',name:target}:{mode:'off'};});
    state.exits.splice(index,1);return refs;
  }

  /* ---------- 出口代理（链式）：流量先走当前线路，再经过这个代理出去 ---------- */
  function makeExit(f) {
    var name = String(f.name || '').trim().slice(0, 30);
    var server = stripBrackets(String(f.server || '').trim().toLowerCase());
    var port = parseInt(f.port, 10);
    var kind = f.kind; // http | https | socks5
    if (!name) throw new Error('请填名称');
    if (['http', 'https', 'socks5'].indexOf(kind) < 0) throw new Error('类型只能是 HTTP、HTTPS 或 SOCKS5');
    if (!server) throw new Error('请填代理地址');
    if (!(isIPv4(server) || isIPv6(server) || /^([a-z0-9-]+\.)+[a-z0-9-]{2,}$/.test(server))) throw new Error('代理地址只能是 IP 或域名');
    if (!(port >= 1 && port <= 65535)) throw new Error('端口要在 1–65535 之间');
    var p = { name: name, type: kind === 'socks5' ? 'socks5' : 'http', server: server, port: port };
    if (f.username) p.username = String(f.username);
    if (f.password) p.password = String(f.password);
    if (kind === 'https') p.tls = true;
    if (kind === 'socks5') p.udp = true;
    return p;
  }

  /* ---------- 按设备选出口：target = DIRECT | AUTO（只走线路）| 某个出口代理的名字 ---------- */
  function makeDevice(ip, name, target, source) {
    ip = String(ip || '').trim();
    var m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip);
    if (!m || [m[1], m[2], m[3], m[4]].some(function (x) { return +x > 255; })) throw new Error('设备 IP 格式不对');
    if (!target) throw new Error('请选择走向');
    var device = { ip: ip, name: String(name || '').slice(0, 40), target: target };
    if (source) device.source = source;
    return device;
  }

  /* ---------- 规则 ---------- */
  function makeRule(kind, value, action) {
    var v = String(value || '').trim().toLowerCase();
    if (action !== 'PROXY' && action !== 'DIRECT') throw new Error('走向只能是代理或直连');
    if (kind === 'domain' || kind === 'exact') {
      v = v.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').replace(/[\/?#].*$/, '').replace(/:\d+$/, '').replace(/^\*?\./, '');
      try { v = new URL('http://' + v).hostname; } catch (e) { throw new Error('域名格式不对'); }
      if (!/^([a-z0-9-]+\.)+[a-z0-9-]{2,}$/.test(v)) throw new Error('域名格式不对，例如 example.com');
    } else if (kind === 'keyword') {
      if (!/^[a-z0-9._-]+$/.test(v)) throw new Error('关键词只能含字母数字和 . _ -');
    } else if (kind === 'ip') {
      if (v.indexOf('/') < 0) v += '/32';
      var m = /^((\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3}))\/(\d{1,2})$/.exec(v);
      if (!m || [m[2], m[3], m[4], m[5]].some(function (x) { return +x > 255; }) || +m[6] > 32) throw new Error('IP 段格式不对，例如 1.2.3.0/24');
    } else {
      throw new Error('未知规则类型');
    }
    return { kind: kind, value: v, action: action };
  }

  function ruleCondition(r) {
    var t = r.kind === 'exact' ? 'DOMAIN' : r.kind === 'domain' ? 'DOMAIN-SUFFIX' : r.kind === 'keyword' ? 'DOMAIN-KEYWORD' : 'IP-CIDR';
    return t + ',' + r.value;
  }

  function ruleLine(r) {
    return ruleCondition(r) + ',' + r.action + (r.kind === 'ip' ? ',no-resolve' : '');
  }

  function hostOf(url) { try { return new URL(url).hostname; } catch (e) { return ''; } }

  /* 某个手动节点在默认线路组里的成员名：接了出口就是「出口@节点」，否则就是节点名 */
  function memberName(state, nodeName) {
    var bindings = state.nodeExits || {};
    var e = Object.prototype.hasOwnProperty.call(bindings, nodeName) ? bindings[nodeName] : '';
    if (!e) return nodeName;
    return (state.exits || []).some(function (x) { return x.name === e; }) ? e + '@' + nodeName : 'REJECT';
  }

  function parseFinalExit(value) {
    if (!value) throw new Error('请选择最终出口：具体家宽或不使用家宽');
    var choice;
    try { choice = JSON.parse(value); } catch (e) { throw new Error('最终出口格式不正确，请重新选择'); }
    if (!Array.isArray(choice)) throw new Error('请重新选择最终出口');
    if (choice[0] === 'off') return { mode: 'off' };
    if (choice[0] === 'fixed' && typeof choice[1] === 'string' && choice[1]) return { mode: 'fixed', name: choice[1] };
    throw new Error('请重新选择最终出口');
  }

  function defaultExitTarget(state) {
    if (!state.exit) return 'AUTO';
    return (state.exits || []).some(function (e) { return e.name === state.exit; }) ? state.exit : 'REJECT';
  }

  function chainChecks(state) {
    var nodes = state.nodes || [], subs = state.subs || [], exits = state.exits || [];
    var bindings = state.nodeExits || {};
    var checks = [];
    function add(source, name, label, unit, front, exitName) {
      var exit = exits.find(function (e) { return e.name === exitName && !e.tls && /^(http|socks5)$/.test(e.type); });
      if (!exit) return;
      var member = exit.name + '@' + unit;
      var alternate = CHECK_PREFIX + member;
      if (nodes.concat(exits).some(function (p) { return p.name === alternate; })) return;
      checks.push({
        source: source, name: name, label: label, front: front, exit: exit,
        member: member, alternate: alternate, alternateType: exit.type === 'http' ? 'socks5' : 'http'
      });
    }
    nodes.forEach(function (n) {
      if (Object.prototype.hasOwnProperty.call(bindings, n.name)) add('node', n.name, n.name, n.name, n.name, bindings[n.name]);
    });
    subs.forEach(function (s) { add('subscription', s.id, s.name, 's:' + s.id, 'SUBG-' + s.id, s.exit); });
    return checks;
  }

  /*
   * 生成完整 mihomo 配置（JSON 是合法 YAML，每个对象直接写成一行）。
   *
   *   AUTO      默认线路：成员是各手动节点（接了出口的写成「出口@节点」）和各订阅（接了出口的写成「出口@订阅」）
   *   SUBG-<id> 订阅内部分组：订阅里所有节点自动选最快，给出口做前置用（有出口时才生成）
   *   <出口名>  出口分组：成员是「出口@每个前置节点/订阅」，测速测整条链；设备页和默认出口选择指向它
   *   PROXY     默认出口选择：AUTO 或某个出口；规则都指向它
   * 「出口@前置」是出口代理的一份拷贝，dialer-proxy 指向那个前置（节点，或订阅分组）。
   */
  function genYaml(state) {
    var nodes = state.nodes || [], subs = state.subs || [], exits = state.exits || [], rules = state.rules || [];
    // 用户规则始终优先，兼容历史保存顺序并保留各层内部顺序。
    rules = rules.filter(function (r) { return !r.preset; }).concat(rules.filter(function (r) { return !!r.preset; }));
    var nodeExit = state.nodeExits || {};
    var mode = ['fallback', 'url-test', 'select'].indexOf(state.mode) >= 0 ? state.mode : 'fallback';
    var testMin = Math.max(1, Math.min(120, parseInt(state.testMinutes, 10) || 10));
    var autoTest = state.autoTest !== false;
    var out = ['# 由 OpenClash 面板自动生成，请勿手改', 'mode: rule', 'log-level: info'];

    var exitMap = Object.create(null); exits.forEach(function (e) { exitMap[e.name] = e; });
    var validExit = function (n) { return n && exitMap[n] ? n : ''; };
    var ids = subs.map(function (s) { return s.id; });
    var devs = (state.deviceRouting === false ? [] : state.devices || []).filter(function (d) { return isIPv4(d.ip || '') && d.target; });
    var proxyDevs = devs.filter(function (d) { return d.source || d.target !== 'DIRECT'; });

    // 前置单元：每个手动节点；每个订阅（用它的内部分组 SUBG-<id> 当前置）
    var units = nodes.map(function (n) { return { label: n.name, dialer: n.name }; })
      .concat(subs.map(function (s) { return { label: 's:' + s.id, dialer: 'SUBG-' + s.id }; }));
    var copies = []; // 出口代理的拷贝
    exits.forEach(function (e) {
      units.forEach(function (u) {
        var c = {}; Object.keys(e).forEach(function (k) { if (k !== 'via') c[k] = e[k]; });
        c.name = e.name + '@' + u.label; c['dialer-proxy'] = u.dialer;
        copies.push(c);
      });
    });

    var pinned = new Map(), pinnedGroups = [];
    var reserved = new Set(RESERVED.concat(nodes.concat(exits, copies).map(function (p) { return p.name; })));
    var nameCounters = Object.create(null);
    function pinName(prefix) {
      prefix = prefix || 'DEVICE-NODE-';
      var count = nameCounters[prefix] || 0;
      var name;
      do { name = prefix + (++count); } while (reserved.has(name));
      nameCounters[prefix] = count;
      reserved.add(name);
      return name;
    }
    function pinSubscription(name, subId, nodeName) {
      var escaped = nodeName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      var sub=subs.find(function(s){return s.id===subId;}),g={ name: name, type: 'select', use: [subId], filter: '^' + escaped + '$', 'empty-fallback': 'REJECT' };
      if(sub && excludedNodePattern(sub))g['exclude-filter']=excludedNodePattern(sub);
      pinnedGroups.push(g);
    }
    proxyDevs.forEach(function (d) {
      if (!d.source) return;
      var key = JSON.stringify([d.source, d.target]);
      if (pinned.has(key)) return;
      var target = 'REJECT';
      if (d.source === 'node' && nodes.some(function (n) { return n.name === d.target; })) {
        target = pinName();
        pinnedGroups.push({ name: target, type: 'select', proxies: [memberName(state, d.target)] });
      } else if (d.source.indexOf('subscription:') === 0) {
        var sub = subs.find(function (s) { return s.id === d.source.slice(13); });
        if (sub && (!sub.exit || validExit(sub.exit))) {
          target = pinName();
          pinSubscription(target, sub.id, d.target);
          if (validExit(sub.exit)) {
            var chain = Object.assign({}, exitMap[sub.exit], { name: pinName(), 'dialer-proxy': target });
            delete chain.via;
            copies.push(chain);
            target = chain.name;
          }
        }
      }
      pinned.set(key, target);
    });

    var ruleTargets = new Map(), noExitGroup;
    function ruleTarget(r) {
      var node = r.node, exit = r.exit;
      var prefix = 'RULE-ROUTE-';
      if (exit && exit.mode === 'fixed' && !validExit(exit.name)) return 'REJECT';
      if (!node && exit && exit.mode === 'off') {
        if (!noExitGroup) noExitGroup = { name: pinName(prefix), 'empty-fallback': 'REJECT' };
        return noExitGroup.name;
      }
      var target = 'REJECT';
      if (!node) {
        if (!exit || exit.mode !== 'fixed') return target;
        target = exit.name;
      } else if (node.source === 'node' && nodes.some(function (n) { return n.name === node.name; })) {
        if (!exit) target = memberName(state, node.name);
        else if (exit.mode === 'off') target = node.name;
        else if (exit.mode === 'fixed') target = exit.name + '@' + node.name;
      } else if (typeof node.source === 'string' && node.source.indexOf('subscription:') === 0 && typeof node.name === 'string' && node.name) {
        var sub = subs.find(function (s) { return s.id === node.source.slice(13); });
        var home = !exit ? sub && sub.exit : exit.mode === 'fixed' ? exit.name : '';
        if (!sub || (home && !validExit(home)) || (exit && ['fixed', 'off'].indexOf(exit.mode) < 0)) return target;
        target = pinName(prefix);
        pinSubscription(target, sub.id, node.name);
        if (home) {
          var chain = Object.assign({}, exitMap[home], { name: pinName(prefix), 'dialer-proxy': target });
          delete chain.via;
          copies.push(chain);
          target = chain.name;
        }
        return target;
      }
      if (target === 'REJECT') return target;
      var name = pinName(prefix);
      pinnedGroups.push({ name: name, type: 'select', proxies: [target] });
      return name;
    }
    rules.forEach(function (r) {
      if (r.action !== 'PROXY' || (!r.node && !r.exit)) return;
      var key = JSON.stringify([r.node || null, r.exit || null]);
      if (!ruleTargets.has(key)) ruleTargets.set(key, ruleTarget(r));
    });

    // 只给已绑定的线路增加备用协议探测项，不加入测速组或转发规则。
    var diagnostics = chainChecks(state).map(function (check) {
      var probe = Object.assign({}, check.exit, { name: check.alternate, type: check.alternateType, 'dialer-proxy': check.front });
      delete probe.via;
      delete probe.tls;
      delete probe.udp;
      return probe;
    });
    var proxyObjs = nodes.concat(copies, diagnostics);
    out.push(proxyObjs.length ? 'proxies:' : 'proxies: []');
    proxyObjs.forEach(function (n) { out.push('- ' + JSON.stringify(n, withoutPanelFields)); });

    if (subs.length) {
      out.push('proxy-providers:');
      subs.forEach(function (s) {
        var prov = {
          type: 'http', url: s.url, path: './proxy_provider/panel_' + s.id + '.yaml',
          interval: (SUB_HOURS.indexOf(s.hours) >= 0 ? s.hours : 24) * 3600,
          header: { 'User-Agent': ['clash.meta'] },
          'health-check': { enable: false }
        };
        out.push('  ' + JSON.stringify(s.id) + ': ' + JSON.stringify(prov));
      });
    }

    // 测速参数：开测速=定时选最快；关测速=只在当前节点断线时才换（阈值极大）；节点多时放慢，小路由器扛不住
    function tune(g, type, many) {
      g.type = type; g.url = HEALTH_URL; g.lazy = true;
      g['expected-status'] = '204';
      g['max-failed-times'] = 2;
      g.interval = type === 'url-test' ? (autoTest ? testMin * 60 : (many ? 300 : 120)) : (many ? 180 : 30);
      // 容差：新线路要比当前线路快这么多才切换。用户网络延迟高（1.5–4.5 秒），250 ms 太迟钝；测速间隔本身限制了切换频率（如 30 分钟一次），取 100 ms。
      if (type === 'url-test') g.tolerance = autoTest ? SWITCH_TOLERANCE_MS : 100000;
    }
    var helperType = mode === 'fallback' ? 'fallback' : 'url-test';

    // AUTO 的成员
    var members = nodes.map(function (n) { return memberName(state, n.name); });
    var useIds = [];
    subs.forEach(function (s) {
      var ve = validExit(s.exit);
      if (ve) members.push(ve + '@s:' + s.id);
      else if (s.exit) members.push('REJECT');
      else if(excludedNodePattern(s))members.push('SUBG-'+s.id);
      else useIds.push(s.id);
    });
    var auto = { name: 'AUTO', 'empty-fallback': 'REJECT' };
    if (!members.length && !useIds.length) {
      auto.type = 'select'; auto.proxies = ['REJECT'];
    } else {
      if (mode === 'select' && state.fixed) {
        var fm = memberName(state, state.fixed), i = members.indexOf(fm);
        if (i > 0) { members.splice(i, 1); members.unshift(fm); }
      }
      auto.type = mode;
      if (members.length) auto.proxies = members;
      if (useIds.length) auto.use = useIds;
      if (mode !== 'select') {
        tune(auto, mode, ids.length > 0 || members.length > 8);
        if (!useIds.length && members.length <= 8) auto.lazy = false;
      }
    }

    if (noExitGroup) {
      var rawNodes = nodes.map(function (n) { return n.name; });
      if (mode === 'select' && rawNodes.indexOf(state.fixed) > 0) {
        rawNodes.splice(rawNodes.indexOf(state.fixed), 1);
        rawNodes.unshift(state.fixed);
      }
      noExitGroup.type = mode;
      var unfilteredIds=[];
      subs.forEach(function(s){if(excludedNodePattern(s))rawNodes.push('SUBG-'+s.id);else unfilteredIds.push(s.id);});
      if (rawNodes.length) noExitGroup.proxies = rawNodes;
      if (unfilteredIds.length) noExitGroup.use = unfilteredIds;
      if (!rawNodes.length && !ids.length) {
        noExitGroup.type = 'select';
        noExitGroup.proxies = ['REJECT'];
      } else if (mode !== 'select') tune(noExitGroup, mode, !!ids.length || rawNodes.length > 8);
      pinnedGroups.push(noExitGroup);
    }
    var groups = [auto];
    subs.forEach(function(s){
      if(!exits.length && !excludedNodePattern(s))return;
      var g={name:'SUBG-'+s.id,use:[s.id],'empty-fallback':'REJECT'};
      if(excludedNodePattern(s))g['exclude-filter']=excludedNodePattern(s);
      tune(g,helperType,true);groups.push(g);
    });
    if (exits.length) {
      exits.forEach(function (e) { // 出口分组
        var g = { name: e.name };
        var ms = units.map(function (u) { return e.name + '@' + u.label; });
        if (!ms.length) { g.type = 'select'; g.proxies = ['REJECT']; }
        else { g.proxies = ms; tune(g, helperType, ids.length > 0 || ms.length > 8); }
        groups.push(g);
      });
    }

    var choices = ['AUTO'];
    exits.forEach(function (e) { choices.push(e.name); });
    if (state.exit && choices.indexOf(state.exit) > 0) {
      choices.splice(choices.indexOf(state.exit), 1); choices.unshift(state.exit);
    }
    groups = groups.concat(pinnedGroups);
    if (defaultExitTarget(state) === 'REJECT') choices = ['REJECT'];
    groups.push({ name: 'PROXY', type: 'select', proxies: choices });
    out.push('proxy-groups:');
    groups.forEach(function (g) { out.push('- ' + JSON.stringify(g)); });

    // 每段连续同走向规则共用一个内联集合；集合顺序保持手动优先及首次匹配语义。
    // 使用 classical 集合让 DOMAIN-KEYWORD 与后缀/精确域名一致，避免 trie 的最长后缀覆盖顺序。
    var dnsPolicy = {}, dnsProviders = {}, dnsBatches = [];
    var dnsHidden = state.dnsHidden !== false; // 旧配置保留原策略；新建/清空明确为 false。
    var aliDns = ['https://223.5.5.5/dns-query#DIRECT', 'https://doh.pub/dns-query#DIRECT'];
    function overseasDns(target) { return ['https://8.8.8.8/dns-query', 'https://1.1.1.1/dns-query'].map(function (url) { return url + '#' + encodeURIComponent(target); }); }
    (dnsHidden ? rules : []).forEach(function (r) {
      if (['domain', 'exact', 'keyword'].indexOf(r.kind) < 0) return;
      var target = r.action === 'DIRECT' ? 'DIRECT' :
        (r.node || r.exit ? ruleTargets.get(JSON.stringify([r.node || null, r.exit || null])) || 'REJECT' : 'PROXY');
      var batch = dnsBatches[dnsBatches.length - 1];
      if (!batch || batch.target !== target) { batch = { target: target, payload: [] }; dnsBatches.push(batch); }
      batch.payload.push(ruleCondition(r));
    });
    dnsBatches.forEach(function (batch, i) {
      var id = 'panel-dns-' + (i + 1);
      dnsProviders[id] = { type: 'inline', behavior: 'classical', payload: batch.payload };
      dnsPolicy['rule-set:' + id] = batch.target === 'DIRECT' ? aliDns : overseasDns(batch.target);
    });
    if (dnsHidden && state.routingMode !== 'proxy-all') dnsPolicy['geosite:cn'] = aliDns;
    var dns = {
      enable: true, ipv6: false, 'enhanced-mode': 'fake-ip', 'fake-ip-range': '198.18.0.1/16',
      listen: '0.0.0.0:7874', 'respect-rules': true, 'prefer-h3': false,
      // Bootstrap only DNS-service hostnames, never ordinary website queries.
      'default-nameserver': ['https://223.5.5.5/dns-query#DIRECT', 'udp://119.29.29.29:53#DIRECT'], 'proxy-server-nameserver': aliDns,
      nameserver: overseasDns('PROXY'), 'nameserver-policy': dnsPolicy
    };
    if (!dnsHidden) {
      var initialDns = ['udp://223.5.5.5:53#DIRECT', 'udp://119.29.29.29:53#DIRECT'];
      dns['default-nameserver'] = ['223.5.5.5', '119.29.29.29'];
      dns['proxy-server-nameserver'] = initialDns;
      dns.nameserver = initialDns;
    }
    out.push('dns: ' + JSON.stringify(dns));
    if (dnsBatches.length) out.push('rule-providers: ' + JSON.stringify(dnsProviders));

    var lines = [], seen = {};
    var exitNames = exits.map(function (e) { return e.name; });
    function deviceRule(d) { return 'SRC-IP-CIDR,' + d.ip + '/32'; }
    function deviceTarget(d) {
      if (d.source) return pinned.get(JSON.stringify([d.source, d.target])) || 'REJECT';
      return d.target === 'AUTO' || exitNames.indexOf(d.target) >= 0 ? d.target : 'REJECT';
    }
    // Mihomo 会跳过不支持 UDP 的出站。紧接着用同一条件拒绝，避免继续匹配到别的出口或直连。
    function pushProxyRule(condition, target, suffix) {
      suffix = suffix || '';
      lines.push(condition + ',' + target + suffix);
      if (target !== 'REJECT') lines.push(condition + ',REJECT' + suffix);
    }
    rules.forEach(function (r) {
      if (r.action !== 'PROXY') {
        lines.push(ruleLine(r));
        return;
      }
      var condition = ruleCondition(r);
      var suffix = r.kind === 'ip' ? ',no-resolve' : '';
      if (r.node || r.exit) {
        pushProxyRule(condition, ruleTargets.get(JSON.stringify([r.node || null, r.exit || null])), suffix);
        return;
      }
      var nested = condition + suffix;
      proxyDevs.forEach(function (d) {
        pushProxyRule('AND,((' + deviceRule(d) + '),(' + nested + '))', deviceTarget(d));
      });
      pushProxyRule(condition, 'PROXY', r.kind === 'ip' ? ',no-resolve' : '');
    });
    nodes.forEach(function (n) {
      if (seen[n.server]) return; seen[n.server] = 1;
      if (isIPv4(n.server)) lines.push('IP-CIDR,' + n.server + '/32,DIRECT,no-resolve');
      else if (isIPv6(n.server)) lines.push('IP-CIDR6,' + n.server + '/128,DIRECT,no-resolve');
      else lines.push('DOMAIN,' + n.server + ',DIRECT');
    });
    subs.forEach(function (s) { // 订阅地址本身直连，方便内核下载
      var h = hostOf(s.url);
      if (h && !seen[h]) { seen[h] = 1; lines.push((isIPv4(h) ? 'IP-CIDR,' + h + '/32,DIRECT,no-resolve' : 'DOMAIN,' + h + ',DIRECT')); }
    });
    devs.forEach(function (d) {
      if (!d.source && d.target === 'DIRECT') lines.push(deviceRule(d) + ',DIRECT');
    });
    lines.push('GEOIP,LAN,DIRECT,no-resolve');
    if (state.routingMode !== 'proxy-all') {
      lines.push('GEOSITE,cn,DIRECT');
      lines.push('GEOIP,CN,DIRECT');
    }
    proxyDevs.forEach(function (d) { pushProxyRule(deviceRule(d), deviceTarget(d)); });
    pushProxyRule('MATCH', 'PROXY');
    out.push('rules:');
    lines.forEach(function (l) { out.push('- ' + JSON.stringify(l)); });
    return out.join('\n') + '\n';
  }


  /* ---------- 查看节点链接：导入时保存原始链接；旧节点从配置还原 ---------- */
  function linkHost(h) { return isIPv6(h) ? '[' + h + ']' : h; }
  function linkQuery(params) {
    var q = Object.keys(params).filter(function (k) { return params[k] !== undefined && params[k] !== '' && params[k] !== null; })
      .map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(params[k]); });
    return q.length ? '?' + q.join('&') : '';
  }
  function b64(text) {
    var bytes = new TextEncoder().encode(text), raw = '';
    bytes.forEach(function (b) { raw += String.fromCharCode(b); });
    return btoa(raw);
  }
  function transportParams(n) {
    var t = { type: n.network || 'tcp' };
    var ws = n['ws-opts'], h2 = n['h2-opts'], http = n['http-opts'], grpc = n['grpc-opts'];
    if (t.type === 'ws' && ws) {
      if (ws['v2ray-http-upgrade']) t.type = 'httpupgrade';
      t.path = ws.path; if (ws.headers && ws.headers.Host) t.host = ws.headers.Host;
    } else if (t.type === 'grpc' && grpc) t.serviceName = grpc['grpc-service-name'];
    else if (t.type === 'h2' && h2) { t.path = h2.path; if (h2.host) t.host = [].concat(h2.host).join(','); }
    else if (t.type === 'http' && http) { t.path = [].concat(http.path || '/')[0]; if (http.headers && http.headers.Host) t.host = [].concat(http.headers.Host).join(','); }
    return t;
  }
  function tlsParams(n, sniKey) {
    var t = {};
    if (n.reality_opts || n['reality-opts']) { t.security = 'reality'; t.pbk = n['reality-opts']['public-key']; t.sid = n['reality-opts']['short-id']; }
    else if (n.tls || n.type === 'trojan') t.security = 'tls';
    if (n[sniKey]) t.sni = n[sniKey];
    if (n['client-fingerprint']) t.fp = n['client-fingerprint'];
    if (n.alpn) t.alpn = [].concat(n.alpn).join(',');
    if (n['skip-cert-verify']) t.allowInsecure = '1';
    if (n['name-cert-verify']) t.vcn = n['name-cert-verify'];
    if (n.fingerprint) t.pcs = n.fingerprint;
    return t;
  }
  function shareTls(n) {
    var t = {};
    if (n.sni) t.sni = n.sni;
    if (n['skip-cert-verify']) t.insecure = '1';
    if (n.alpn) t.alpn = [].concat(n.alpn).join(',');
    if (n['client-fingerprint']) t.fp = n['client-fingerprint'];
    if (n.fingerprint) t.pinSHA256 = n.fingerprint;
    return t;
  }
  function rebuildLink(n) {
    var tag = '#' + encodeURIComponent(n.name || ''), host = linkHost(n.server), at = host + ':' + n.port;
    if (n.type === 'vless') {
      var tp = transportParams(n), tl = tlsParams(n, 'servername');
      return 'vless://' + encodeURIComponent(n.uuid) + '@' + at + linkQuery(Object.assign({ encryption: 'none', flow: n.flow }, tl, tp)) + tag;
    }
    if (n.type === 'trojan') {
      return 'trojan://' + encodeURIComponent(n.password) + '@' + at + linkQuery(Object.assign({}, tlsParams(n, 'sni'), transportParams(n))) + tag;
    }
    if (n.type === 'vmess') {
      var v = transportParams(n), vt = tlsParams(n, 'servername'), net = v.type, header = 'none';
      if (net === 'http') { net = 'tcp'; header = 'http'; }
      var j = { v: '2', ps: n.name, add: n.server, port: String(n.port), id: n.uuid, aid: String(n.alterId || 0), scy: n.cipher || 'auto',
        net: net, type: header, host: v.host || '', path: v.path || v.serviceName || '', tls: vt.security || '', sni: vt.sni || '', alpn: vt.alpn || '', fp: vt.fp || '' };
      if (net === 'httpupgrade') j.net = 'httpupgrade';
      if (vt.allowInsecure) j.allowInsecure = '1';
      if (vt.security === 'reality') { j.pbk = vt.pbk; j.sid = vt.sid; }
      if (net === 'grpc') j.serviceName = v.serviceName || '';
      return 'vmess://' + b64(JSON.stringify(j));
    }
    if (n.type === 'ss') {
      var creds = n.cipher + ':' + n.password;
      var user = n.cipher.indexOf('2022-') === 0 ? n.cipher + ':' + encodeURIComponent(n.password) : b64(creds).replace(/=+$/, '');
      var plugin = '';
      if (n.plugin === 'obfs') plugin = 'obfs-local;obfs=' + n['plugin-opts'].mode + (n['plugin-opts'].host ? ';obfs-host=' + n['plugin-opts'].host : '');
      else if (n.plugin === 'v2ray-plugin') {
        var o = n['plugin-opts'] || {};
        plugin = 'v2ray-plugin;mode=websocket' + (o.host ? ';host=' + o.host : '') + (o.path ? ';path=' + o.path : '') + (o.tls ? ';tls' : '') + (o.mux !== undefined ? ';mux=' + (o.mux ? 1 : 0) : '');
      }
      return 'ss://' + user + '@' + at + (plugin ? '/' + linkQuery({ plugin: plugin }) : '') + tag;
    }
    if (n.type === 'hysteria2' || n.type === 'anytls') {
      var hp = shareTls(n);
      if (n.type === 'hysteria2') { if (n.obfs) { hp.obfs = n.obfs; hp['obfs-password'] = n['obfs-password']; } if (n.up) hp.up = n.up; if (n.down) hp.down = n.down; }
      return (n.type === 'hysteria2' ? 'hysteria2://' : 'anytls://') + encodeURIComponent(n.password) + '@' + host + ':' + (n.ports || n.port) + linkQuery(hp) + tag;
    }
    if (n.type === 'tuic') {
      var tu = shareTls(n);
      if (n['congestion-controller']) tu.congestion_control = n['congestion-controller'];
      if (n['udp-relay-mode']) tu.udp_relay_mode = n['udp-relay-mode'];
      if (n['disable-sni'] !== undefined) tu.disable_sni = n['disable-sni'] ? '1' : '0';
      if (n['reduce-rtt'] !== undefined) tu.reduce_rtt = n['reduce-rtt'] ? '1' : '0';
      var auth = n.uuid ? encodeURIComponent(n.uuid) + ':' + encodeURIComponent(n.password || '') : encodeURIComponent(n.token);
      return 'tuic://' + auth + '@' + at + linkQuery(tu) + tag;
    }
    if (n.type === 'hysteria') {
      var hy = Object.assign({ auth: n['auth-str'], protocol: n.protocol, up: n.up, down: n.down, obfs: n.obfs }, shareTls(n));
      return 'hysteria://' + at + linkQuery(hy) + tag;
    }
    if (n.type === 'socks5' || n.type === 'http') {
      var cred = n.username ? encodeURIComponent(n.username) + (n.password ? ':' + encodeURIComponent(n.password) : '') + '@' : '';
      var sp = n.tls ? Object.assign({ tls: '1' }, shareTls(n)) : {};
      if (n.type === 'socks5') { if (n.udp === false) sp.udp = '0'; return 'socks5://' + cred + at + linkQuery(sp) + tag; }
      return (n.tls ? 'https-proxy://' : 'http-proxy://') + cred + at + linkQuery(n.tls ? shareTls(n) : {}) + tag;
    }
    return '';
  }
  // 返回给用户复制的链接：优先导入时的原始链接；还原不了（如 SSR）返回空字符串。
  function nodeLink(n) {
    if (n && typeof n._link === 'string' && n._link) return n._link;
    try { return rebuildLink(n || {}); } catch (e) { return ''; }
  }
  function withoutPanelFields(key, value) { return key === '_link' ? undefined : value; }

  /* ---------- 二维码：内置 qrcode-generator 1.4.4（Kazuhiko Arase，MIT 许可，http://www.d-project.com/） ----------
     只在浏览器里计算，不联网、不经过路由器。 */
  var qrcode = function() {
    /**
     * qrcode
     * @param typeNumber 1 to 40
     * @param errorCorrectionLevel 'L','M','Q','H'
     */
    var qrcode = function(typeNumber, errorCorrectionLevel) {
      var PAD0 = 0xEC;
      var PAD1 = 0x11;
      var _typeNumber = typeNumber;
      var _errorCorrectionLevel = QRErrorCorrectionLevel[errorCorrectionLevel];
      var _modules = null;
      var _moduleCount = 0;
      var _dataCache = null;
      var _dataList = [];
      var _this = {};
      var makeImpl = function(test, maskPattern) {
        _moduleCount = _typeNumber * 4 + 17;
        _modules = function(moduleCount) {
          var modules = new Array(moduleCount);
          for (var row = 0; row < moduleCount; row += 1) {
            modules[row] = new Array(moduleCount);
            for (var col = 0; col < moduleCount; col += 1) {
              modules[row][col] = null;
            }
          }
          return modules;
        }(_moduleCount);
        setupPositionProbePattern(0, 0);
        setupPositionProbePattern(_moduleCount - 7, 0);
        setupPositionProbePattern(0, _moduleCount - 7);
        setupPositionAdjustPattern();
        setupTimingPattern();
        setupTypeInfo(test, maskPattern);
        if (_typeNumber >= 7) {
          setupTypeNumber(test);
        }
        if (_dataCache == null) {
          _dataCache = createData(_typeNumber, _errorCorrectionLevel, _dataList);
        }
        mapData(_dataCache, maskPattern);
      };
      var setupPositionProbePattern = function(row, col) {
        for (var r = -1; r <= 7; r += 1) {
          if (row + r <= -1 || _moduleCount <= row + r) continue;
          for (var c = -1; c <= 7; c += 1) {
            if (col + c <= -1 || _moduleCount <= col + c) continue;
            if ( (0 <= r && r <= 6 && (c == 0 || c == 6) )
                || (0 <= c && c <= 6 && (r == 0 || r == 6) )
                || (2 <= r && r <= 4 && 2 <= c && c <= 4) ) {
              _modules[row + r][col + c] = true;
            } else {
              _modules[row + r][col + c] = false;
            }
          }
        }
      };
      var getBestMaskPattern = function() {
        var minLostPoint = 0;
        var pattern = 0;
        for (var i = 0; i < 8; i += 1) {
          makeImpl(true, i);
          var lostPoint = QRUtil.getLostPoint(_this);
          if (i == 0 || minLostPoint > lostPoint) {
            minLostPoint = lostPoint;
            pattern = i;
          }
        }
        return pattern;
      };
      var setupTimingPattern = function() {
        for (var r = 8; r < _moduleCount - 8; r += 1) {
          if (_modules[r][6] != null) {
            continue;
          }
          _modules[r][6] = (r % 2 == 0);
        }
        for (var c = 8; c < _moduleCount - 8; c += 1) {
          if (_modules[6][c] != null) {
            continue;
          }
          _modules[6][c] = (c % 2 == 0);
        }
      };
      var setupPositionAdjustPattern = function() {
        var pos = QRUtil.getPatternPosition(_typeNumber);
        for (var i = 0; i < pos.length; i += 1) {
          for (var j = 0; j < pos.length; j += 1) {
            var row = pos[i];
            var col = pos[j];
            if (_modules[row][col] != null) {
              continue;
            }
            for (var r = -2; r <= 2; r += 1) {
              for (var c = -2; c <= 2; c += 1) {
                if (r == -2 || r == 2 || c == -2 || c == 2
                    || (r == 0 && c == 0) ) {
                  _modules[row + r][col + c] = true;
                } else {
                  _modules[row + r][col + c] = false;
                }
              }
            }
          }
        }
      };
      var setupTypeNumber = function(test) {
        var bits = QRUtil.getBCHTypeNumber(_typeNumber);
        for (var i = 0; i < 18; i += 1) {
          var mod = (!test && ( (bits >> i) & 1) == 1);
          _modules[Math.floor(i / 3)][i % 3 + _moduleCount - 8 - 3] = mod;
        }
        for (var i = 0; i < 18; i += 1) {
          var mod = (!test && ( (bits >> i) & 1) == 1);
          _modules[i % 3 + _moduleCount - 8 - 3][Math.floor(i / 3)] = mod;
        }
      };
      var setupTypeInfo = function(test, maskPattern) {
        var data = (_errorCorrectionLevel << 3) | maskPattern;
        var bits = QRUtil.getBCHTypeInfo(data);
        for (var i = 0; i < 15; i += 1) {
          var mod = (!test && ( (bits >> i) & 1) == 1);
          if (i < 6) {
            _modules[i][8] = mod;
          } else if (i < 8) {
            _modules[i + 1][8] = mod;
          } else {
            _modules[_moduleCount - 15 + i][8] = mod;
          }
        }
        for (var i = 0; i < 15; i += 1) {
          var mod = (!test && ( (bits >> i) & 1) == 1);
          if (i < 8) {
            _modules[8][_moduleCount - i - 1] = mod;
          } else if (i < 9) {
            _modules[8][15 - i - 1 + 1] = mod;
          } else {
            _modules[8][15 - i - 1] = mod;
          }
        }
        _modules[_moduleCount - 8][8] = (!test);
      };
      var mapData = function(data, maskPattern) {
        var inc = -1;
        var row = _moduleCount - 1;
        var bitIndex = 7;
        var byteIndex = 0;
        var maskFunc = QRUtil.getMaskFunction(maskPattern);
        for (var col = _moduleCount - 1; col > 0; col -= 2) {
          if (col == 6) col -= 1;
          while (true) {
            for (var c = 0; c < 2; c += 1) {
              if (_modules[row][col - c] == null) {
                var dark = false;
                if (byteIndex < data.length) {
                  dark = ( ( (data[byteIndex] >>> bitIndex) & 1) == 1);
                }
                var mask = maskFunc(row, col - c);
                if (mask) {
                  dark = !dark;
                }
                _modules[row][col - c] = dark;
                bitIndex -= 1;
                if (bitIndex == -1) {
                  byteIndex += 1;
                  bitIndex = 7;
                }
              }
            }
            row += inc;
            if (row < 0 || _moduleCount <= row) {
              row -= inc;
              inc = -inc;
              break;
            }
          }
        }
      };
      var createBytes = function(buffer, rsBlocks) {
        var offset = 0;
        var maxDcCount = 0;
        var maxEcCount = 0;
        var dcdata = new Array(rsBlocks.length);
        var ecdata = new Array(rsBlocks.length);
        for (var r = 0; r < rsBlocks.length; r += 1) {
          var dcCount = rsBlocks[r].dataCount;
          var ecCount = rsBlocks[r].totalCount - dcCount;
          maxDcCount = Math.max(maxDcCount, dcCount);
          maxEcCount = Math.max(maxEcCount, ecCount);
          dcdata[r] = new Array(dcCount);
          for (var i = 0; i < dcdata[r].length; i += 1) {
            dcdata[r][i] = 0xff & buffer.getBuffer()[i + offset];
          }
          offset += dcCount;
          var rsPoly = QRUtil.getErrorCorrectPolynomial(ecCount);
          var rawPoly = qrPolynomial(dcdata[r], rsPoly.getLength() - 1);
          var modPoly = rawPoly.mod(rsPoly);
          ecdata[r] = new Array(rsPoly.getLength() - 1);
          for (var i = 0; i < ecdata[r].length; i += 1) {
            var modIndex = i + modPoly.getLength() - ecdata[r].length;
            ecdata[r][i] = (modIndex >= 0)? modPoly.getAt(modIndex) : 0;
          }
        }
        var totalCodeCount = 0;
        for (var i = 0; i < rsBlocks.length; i += 1) {
          totalCodeCount += rsBlocks[i].totalCount;
        }
        var data = new Array(totalCodeCount);
        var index = 0;
        for (var i = 0; i < maxDcCount; i += 1) {
          for (var r = 0; r < rsBlocks.length; r += 1) {
            if (i < dcdata[r].length) {
              data[index] = dcdata[r][i];
              index += 1;
            }
          }
        }
        for (var i = 0; i < maxEcCount; i += 1) {
          for (var r = 0; r < rsBlocks.length; r += 1) {
            if (i < ecdata[r].length) {
              data[index] = ecdata[r][i];
              index += 1;
            }
          }
        }
        return data;
      };
      var createData = function(typeNumber, errorCorrectionLevel, dataList) {
        var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, errorCorrectionLevel);
        var buffer = qrBitBuffer();
        for (var i = 0; i < dataList.length; i += 1) {
          var data = dataList[i];
          buffer.put(data.getMode(), 4);
          buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
          data.write(buffer);
        }
        var totalDataCount = 0;
        for (var i = 0; i < rsBlocks.length; i += 1) {
          totalDataCount += rsBlocks[i].dataCount;
        }
        if (buffer.getLengthInBits() > totalDataCount * 8) {
          throw 'code length overflow. ('
            + buffer.getLengthInBits()
            + '>'
            + totalDataCount * 8
            + ')';
        }
        if (buffer.getLengthInBits() + 4 <= totalDataCount * 8) {
          buffer.put(0, 4);
        }
        while (buffer.getLengthInBits() % 8 != 0) {
          buffer.putBit(false);
        }
        while (true) {
          if (buffer.getLengthInBits() >= totalDataCount * 8) {
            break;
          }
          buffer.put(PAD0, 8);
          if (buffer.getLengthInBits() >= totalDataCount * 8) {
            break;
          }
          buffer.put(PAD1, 8);
        }
        return createBytes(buffer, rsBlocks);
      };
      _this.addData = function(data, mode) {
        mode = mode || 'Byte';
        var newData = null;
        switch(mode) {
        case 'Numeric' :
          newData = qrNumber(data);
          break;
        case 'Alphanumeric' :
          newData = qrAlphaNum(data);
          break;
        case 'Byte' :
          newData = qr8BitByte(data);
          break;
        case 'Kanji' :
          newData = qrKanji(data);
          break;
        default :
          throw 'mode:' + mode;
        }
        _dataList.push(newData);
        _dataCache = null;
      };
      _this.isDark = function(row, col) {
        if (row < 0 || _moduleCount <= row || col < 0 || _moduleCount <= col) {
          throw row + ',' + col;
        }
        return _modules[row][col];
      };
      _this.getModuleCount = function() {
        return _moduleCount;
      };
      _this.make = function() {
        if (_typeNumber < 1) {
          var typeNumber = 1;
          for (; typeNumber < 40; typeNumber++) {
            var rsBlocks = QRRSBlock.getRSBlocks(typeNumber, _errorCorrectionLevel);
            var buffer = qrBitBuffer();
            for (var i = 0; i < _dataList.length; i++) {
              var data = _dataList[i];
              buffer.put(data.getMode(), 4);
              buffer.put(data.getLength(), QRUtil.getLengthInBits(data.getMode(), typeNumber) );
              data.write(buffer);
            }
            var totalDataCount = 0;
            for (var i = 0; i < rsBlocks.length; i++) {
              totalDataCount += rsBlocks[i].dataCount;
            }
            if (buffer.getLengthInBits() <= totalDataCount * 8) {
              break;
            }
          }
          _typeNumber = typeNumber;
        }
        makeImpl(false, getBestMaskPattern() );
      };
      _this.createTableTag = function(cellSize, margin) {
        cellSize = cellSize || 2;
        margin = (typeof margin == 'undefined')? cellSize * 4 : margin;
        var qrHtml = '';
        qrHtml += '<table style="';
        qrHtml += ' border-width: 0px; border-style: none;';
        qrHtml += ' border-collapse: collapse;';
        qrHtml += ' padding: 0px; margin: ' + margin + 'px;';
        qrHtml += '">';
        qrHtml += '<tbody>';
        for (var r = 0; r < _this.getModuleCount(); r += 1) {
          qrHtml += '<tr>';
          for (var c = 0; c < _this.getModuleCount(); c += 1) {
            qrHtml += '<td style="';
            qrHtml += ' border-width: 0px; border-style: none;';
            qrHtml += ' border-collapse: collapse;';
            qrHtml += ' padding: 0px; margin: 0px;';
            qrHtml += ' width: ' + cellSize + 'px;';
            qrHtml += ' height: ' + cellSize + 'px;';
            qrHtml += ' background-color: ';
            qrHtml += _this.isDark(r, c)? '#000000' : '#ffffff';
            qrHtml += ';';
            qrHtml += '"/>';
          }
          qrHtml += '</tr>';
        }
        qrHtml += '</tbody>';
        qrHtml += '</table>';
        return qrHtml;
      };
      _this.createSvgTag = function(cellSize, margin, alt, title) {
        var opts = {};
        if (typeof arguments[0] == 'object') {
          opts = arguments[0];
          cellSize = opts.cellSize;
          margin = opts.margin;
          alt = opts.alt;
          title = opts.title;
        }
        cellSize = cellSize || 2;
        margin = (typeof margin == 'undefined')? cellSize * 4 : margin;
        alt = (typeof alt === 'string') ? {text: alt} : alt || {};
        alt.text = alt.text || null;
        alt.id = (alt.text) ? alt.id || 'qrcode-description' : null;
        title = (typeof title === 'string') ? {text: title} : title || {};
        title.text = title.text || null;
        title.id = (title.text) ? title.id || 'qrcode-title' : null;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var c, mc, r, mr, qrSvg='', rect;
        rect = 'l' + cellSize + ',0 0,' + cellSize +
          ' -' + cellSize + ',0 0,-' + cellSize + 'z ';
        qrSvg += '<svg version="1.1" xmlns="http://www.w3.org/2000/svg"';
        qrSvg += !opts.scalable ? ' width="' + size + 'px" height="' + size + 'px"' : '';
        qrSvg += ' viewBox="0 0 ' + size + ' ' + size + '" ';
        qrSvg += ' preserveAspectRatio="xMinYMin meet"';
        qrSvg += (title.text || alt.text) ? ' role="img" aria-labelledby="' +
            escapeXml([title.id, alt.id].join(' ').trim() ) + '"' : '';
        qrSvg += '>';
        qrSvg += (title.text) ? '<title id="' + escapeXml(title.id) + '">' +
            escapeXml(title.text) + '</title>' : '';
        qrSvg += (alt.text) ? '<description id="' + escapeXml(alt.id) + '">' +
            escapeXml(alt.text) + '</description>' : '';
        qrSvg += '<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>';
        qrSvg += '<path d="';
        for (r = 0; r < _this.getModuleCount(); r += 1) {
          mr = r * cellSize + margin;
          for (c = 0; c < _this.getModuleCount(); c += 1) {
            if (_this.isDark(r, c) ) {
              mc = c*cellSize+margin;
              qrSvg += 'M' + mc + ',' + mr + rect;
            }
          }
        }
        qrSvg += '" stroke="transparent" fill="black"/>';
        qrSvg += '</svg>';
        return qrSvg;
      };
      _this.createDataURL = function(cellSize, margin) {
        cellSize = cellSize || 2;
        margin = (typeof margin == 'undefined')? cellSize * 4 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var min = margin;
        var max = size - margin;
        return createDataURL(size, size, function(x, y) {
          if (min <= x && x < max && min <= y && y < max) {
            var c = Math.floor( (x - min) / cellSize);
            var r = Math.floor( (y - min) / cellSize);
            return _this.isDark(r, c)? 0 : 1;
          } else {
            return 1;
          }
        } );
      };
      _this.createImgTag = function(cellSize, margin, alt) {
        cellSize = cellSize || 2;
        margin = (typeof margin == 'undefined')? cellSize * 4 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var img = '';
        img += '<img';
        img += '\u0020src="';
        img += _this.createDataURL(cellSize, margin);
        img += '"';
        img += '\u0020width="';
        img += size;
        img += '"';
        img += '\u0020height="';
        img += size;
        img += '"';
        if (alt) {
          img += '\u0020alt="';
          img += escapeXml(alt);
          img += '"';
        }
        img += '/>';
        return img;
      };
      var escapeXml = function(s) {
        var escaped = '';
        for (var i = 0; i < s.length; i += 1) {
          var c = s.charAt(i);
          switch(c) {
          case '<': escaped += '&lt;'; break;
          case '>': escaped += '&gt;'; break;
          case '&': escaped += '&amp;'; break;
          case '"': escaped += '&quot;'; break;
          default : escaped += c; break;
          }
        }
        return escaped;
      };
      var _createHalfASCII = function(margin) {
        var cellSize = 1;
        margin = (typeof margin == 'undefined')? cellSize * 2 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var min = margin;
        var max = size - margin;
        var y, x, r1, r2, p;
        var blocks = {
          '██': '█',
          '█ ': '▀',
          ' █': '▄',
          '  ': ' '
        };
        var blocksLastLineNoMargin = {
          '██': '▀',
          '█ ': '▀',
          ' █': ' ',
          '  ': ' '
        };
        var ascii = '';
        for (y = 0; y < size; y += 2) {
          r1 = Math.floor((y - min) / cellSize);
          r2 = Math.floor((y + 1 - min) / cellSize);
          for (x = 0; x < size; x += 1) {
            p = '█';
            if (min <= x && x < max && min <= y && y < max && _this.isDark(r1, Math.floor((x - min) / cellSize))) {
              p = ' ';
            }
            if (min <= x && x < max && min <= y+1 && y+1 < max && _this.isDark(r2, Math.floor((x - min) / cellSize))) {
              p += ' ';
            }
            else {
              p += '█';
            }
            ascii += (margin < 1 && y+1 >= max) ? blocksLastLineNoMargin[p] : blocks[p];
          }
          ascii += '\n';
        }
        if (size % 2 && margin > 0) {
          return ascii.substring(0, ascii.length - size - 1) + Array(size+1).join('▀');
        }
        return ascii.substring(0, ascii.length-1);
      };
      _this.createASCII = function(cellSize, margin) {
        cellSize = cellSize || 1;
        if (cellSize < 2) {
          return _createHalfASCII(margin);
        }
        cellSize -= 1;
        margin = (typeof margin == 'undefined')? cellSize * 2 : margin;
        var size = _this.getModuleCount() * cellSize + margin * 2;
        var min = margin;
        var max = size - margin;
        var y, x, r, p;
        var white = Array(cellSize+1).join('██');
        var black = Array(cellSize+1).join('  ');
        var ascii = '';
        var line = '';
        for (y = 0; y < size; y += 1) {
          r = Math.floor( (y - min) / cellSize);
          line = '';
          for (x = 0; x < size; x += 1) {
            p = 1;
            if (min <= x && x < max && min <= y && y < max && _this.isDark(r, Math.floor((x - min) / cellSize))) {
              p = 0;
            }
            line += p ? white : black;
          }
          for (r = 0; r < cellSize; r += 1) {
            ascii += line + '\n';
          }
        }
        return ascii.substring(0, ascii.length-1);
      };
      _this.renderTo2dContext = function(context, cellSize) {
        cellSize = cellSize || 2;
        var length = _this.getModuleCount();
        for (var row = 0; row < length; row++) {
          for (var col = 0; col < length; col++) {
            context.fillStyle = _this.isDark(row, col) ? 'black' : 'white';
            context.fillRect(row * cellSize, col * cellSize, cellSize, cellSize);
          }
        }
      }
      return _this;
    };
    qrcode.stringToBytesFuncs = {
      'default' : function(s) {
        var bytes = [];
        for (var i = 0; i < s.length; i += 1) {
          var c = s.charCodeAt(i);
          bytes.push(c & 0xff);
        }
        return bytes;
      }
    };
    qrcode.stringToBytes = qrcode.stringToBytesFuncs['default'];
    /**
     * @param unicodeData base64 string of byte array.
     * [16bit Unicode],[16bit Bytes], ...
     * @param numChars
     */
    qrcode.createStringToBytes = function(unicodeData, numChars) {
      var unicodeMap = function() {
        var bin = base64DecodeInputStream(unicodeData);
        var read = function() {
          var b = bin.read();
          if (b == -1) throw 'eof';
          return b;
        };
        var count = 0;
        var unicodeMap = {};
        while (true) {
          var b0 = bin.read();
          if (b0 == -1) break;
          var b1 = read();
          var b2 = read();
          var b3 = read();
          var k = String.fromCharCode( (b0 << 8) | b1);
          var v = (b2 << 8) | b3;
          unicodeMap[k] = v;
          count += 1;
        }
        if (count != numChars) {
          throw count + ' != ' + numChars;
        }
        return unicodeMap;
      }();
      var unknownChar = '?'.charCodeAt(0);
      return function(s) {
        var bytes = [];
        for (var i = 0; i < s.length; i += 1) {
          var c = s.charCodeAt(i);
          if (c < 128) {
            bytes.push(c);
          } else {
            var b = unicodeMap[s.charAt(i)];
            if (typeof b == 'number') {
              if ( (b & 0xff) == b) {
                bytes.push(b);
              } else {
                bytes.push(b >>> 8);
                bytes.push(b & 0xff);
              }
            } else {
              bytes.push(unknownChar);
            }
          }
        }
        return bytes;
      };
    };
    var QRMode = {
      MODE_NUMBER :    1 << 0,
      MODE_ALPHA_NUM : 1 << 1,
      MODE_8BIT_BYTE : 1 << 2,
      MODE_KANJI :     1 << 3
    };
    var QRErrorCorrectionLevel = {
      L : 1,
      M : 0,
      Q : 3,
      H : 2
    };
    var QRMaskPattern = {
      PATTERN000 : 0,
      PATTERN001 : 1,
      PATTERN010 : 2,
      PATTERN011 : 3,
      PATTERN100 : 4,
      PATTERN101 : 5,
      PATTERN110 : 6,
      PATTERN111 : 7
    };
    var QRUtil = function() {
      var PATTERN_POSITION_TABLE = [
        [],
        [6, 18],
        [6, 22],
        [6, 26],
        [6, 30],
        [6, 34],
        [6, 22, 38],
        [6, 24, 42],
        [6, 26, 46],
        [6, 28, 50],
        [6, 30, 54],
        [6, 32, 58],
        [6, 34, 62],
        [6, 26, 46, 66],
        [6, 26, 48, 70],
        [6, 26, 50, 74],
        [6, 30, 54, 78],
        [6, 30, 56, 82],
        [6, 30, 58, 86],
        [6, 34, 62, 90],
        [6, 28, 50, 72, 94],
        [6, 26, 50, 74, 98],
        [6, 30, 54, 78, 102],
        [6, 28, 54, 80, 106],
        [6, 32, 58, 84, 110],
        [6, 30, 58, 86, 114],
        [6, 34, 62, 90, 118],
        [6, 26, 50, 74, 98, 122],
        [6, 30, 54, 78, 102, 126],
        [6, 26, 52, 78, 104, 130],
        [6, 30, 56, 82, 108, 134],
        [6, 34, 60, 86, 112, 138],
        [6, 30, 58, 86, 114, 142],
        [6, 34, 62, 90, 118, 146],
        [6, 30, 54, 78, 102, 126, 150],
        [6, 24, 50, 76, 102, 128, 154],
        [6, 28, 54, 80, 106, 132, 158],
        [6, 32, 58, 84, 110, 136, 162],
        [6, 26, 54, 82, 110, 138, 166],
        [6, 30, 58, 86, 114, 142, 170]
      ];
      var G15 = (1 << 10) | (1 << 8) | (1 << 5) | (1 << 4) | (1 << 2) | (1 << 1) | (1 << 0);
      var G18 = (1 << 12) | (1 << 11) | (1 << 10) | (1 << 9) | (1 << 8) | (1 << 5) | (1 << 2) | (1 << 0);
      var G15_MASK = (1 << 14) | (1 << 12) | (1 << 10) | (1 << 4) | (1 << 1);
      var _this = {};
      var getBCHDigit = function(data) {
        var digit = 0;
        while (data != 0) {
          digit += 1;
          data >>>= 1;
        }
        return digit;
      };
      _this.getBCHTypeInfo = function(data) {
        var d = data << 10;
        while (getBCHDigit(d) - getBCHDigit(G15) >= 0) {
          d ^= (G15 << (getBCHDigit(d) - getBCHDigit(G15) ) );
        }
        return ( (data << 10) | d) ^ G15_MASK;
      };
      _this.getBCHTypeNumber = function(data) {
        var d = data << 12;
        while (getBCHDigit(d) - getBCHDigit(G18) >= 0) {
          d ^= (G18 << (getBCHDigit(d) - getBCHDigit(G18) ) );
        }
        return (data << 12) | d;
      };
      _this.getPatternPosition = function(typeNumber) {
        return PATTERN_POSITION_TABLE[typeNumber - 1];
      };
      _this.getMaskFunction = function(maskPattern) {
        switch (maskPattern) {
        case QRMaskPattern.PATTERN000 :
          return function(i, j) { return (i + j) % 2 == 0; };
        case QRMaskPattern.PATTERN001 :
          return function(i, j) { return i % 2 == 0; };
        case QRMaskPattern.PATTERN010 :
          return function(i, j) { return j % 3 == 0; };
        case QRMaskPattern.PATTERN011 :
          return function(i, j) { return (i + j) % 3 == 0; };
        case QRMaskPattern.PATTERN100 :
          return function(i, j) { return (Math.floor(i / 2) + Math.floor(j / 3) ) % 2 == 0; };
        case QRMaskPattern.PATTERN101 :
          return function(i, j) { return (i * j) % 2 + (i * j) % 3 == 0; };
        case QRMaskPattern.PATTERN110 :
          return function(i, j) { return ( (i * j) % 2 + (i * j) % 3) % 2 == 0; };
        case QRMaskPattern.PATTERN111 :
          return function(i, j) { return ( (i * j) % 3 + (i + j) % 2) % 2 == 0; };
        default :
          throw 'bad maskPattern:' + maskPattern;
        }
      };
      _this.getErrorCorrectPolynomial = function(errorCorrectLength) {
        var a = qrPolynomial([1], 0);
        for (var i = 0; i < errorCorrectLength; i += 1) {
          a = a.multiply(qrPolynomial([1, QRMath.gexp(i)], 0) );
        }
        return a;
      };
      _this.getLengthInBits = function(mode, type) {
        if (1 <= type && type < 10) {
          switch(mode) {
          case QRMode.MODE_NUMBER    : return 10;
          case QRMode.MODE_ALPHA_NUM : return 9;
          case QRMode.MODE_8BIT_BYTE : return 8;
          case QRMode.MODE_KANJI     : return 8;
          default :
            throw 'mode:' + mode;
          }
        } else if (type < 27) {
          switch(mode) {
          case QRMode.MODE_NUMBER    : return 12;
          case QRMode.MODE_ALPHA_NUM : return 11;
          case QRMode.MODE_8BIT_BYTE : return 16;
          case QRMode.MODE_KANJI     : return 10;
          default :
            throw 'mode:' + mode;
          }
        } else if (type < 41) {
          switch(mode) {
          case QRMode.MODE_NUMBER    : return 14;
          case QRMode.MODE_ALPHA_NUM : return 13;
          case QRMode.MODE_8BIT_BYTE : return 16;
          case QRMode.MODE_KANJI     : return 12;
          default :
            throw 'mode:' + mode;
          }
        } else {
          throw 'type:' + type;
        }
      };
      _this.getLostPoint = function(qrcode) {
        var moduleCount = qrcode.getModuleCount();
        var lostPoint = 0;
        for (var row = 0; row < moduleCount; row += 1) {
          for (var col = 0; col < moduleCount; col += 1) {
            var sameCount = 0;
            var dark = qrcode.isDark(row, col);
            for (var r = -1; r <= 1; r += 1) {
              if (row + r < 0 || moduleCount <= row + r) {
                continue;
              }
              for (var c = -1; c <= 1; c += 1) {
                if (col + c < 0 || moduleCount <= col + c) {
                  continue;
                }
                if (r == 0 && c == 0) {
                  continue;
                }
                if (dark == qrcode.isDark(row + r, col + c) ) {
                  sameCount += 1;
                }
              }
            }
            if (sameCount > 5) {
              lostPoint += (3 + sameCount - 5);
            }
          }
        };
        for (var row = 0; row < moduleCount - 1; row += 1) {
          for (var col = 0; col < moduleCount - 1; col += 1) {
            var count = 0;
            if (qrcode.isDark(row, col) ) count += 1;
            if (qrcode.isDark(row + 1, col) ) count += 1;
            if (qrcode.isDark(row, col + 1) ) count += 1;
            if (qrcode.isDark(row + 1, col + 1) ) count += 1;
            if (count == 0 || count == 4) {
              lostPoint += 3;
            }
          }
        }
        for (var row = 0; row < moduleCount; row += 1) {
          for (var col = 0; col < moduleCount - 6; col += 1) {
            if (qrcode.isDark(row, col)
                && !qrcode.isDark(row, col + 1)
                &&  qrcode.isDark(row, col + 2)
                &&  qrcode.isDark(row, col + 3)
                &&  qrcode.isDark(row, col + 4)
                && !qrcode.isDark(row, col + 5)
                &&  qrcode.isDark(row, col + 6) ) {
              lostPoint += 40;
            }
          }
        }
        for (var col = 0; col < moduleCount; col += 1) {
          for (var row = 0; row < moduleCount - 6; row += 1) {
            if (qrcode.isDark(row, col)
                && !qrcode.isDark(row + 1, col)
                &&  qrcode.isDark(row + 2, col)
                &&  qrcode.isDark(row + 3, col)
                &&  qrcode.isDark(row + 4, col)
                && !qrcode.isDark(row + 5, col)
                &&  qrcode.isDark(row + 6, col) ) {
              lostPoint += 40;
            }
          }
        }
        var darkCount = 0;
        for (var col = 0; col < moduleCount; col += 1) {
          for (var row = 0; row < moduleCount; row += 1) {
            if (qrcode.isDark(row, col) ) {
              darkCount += 1;
            }
          }
        }
        var ratio = Math.abs(100 * darkCount / moduleCount / moduleCount - 50) / 5;
        lostPoint += ratio * 10;
        return lostPoint;
      };
      return _this;
    }();
    var QRMath = function() {
      var EXP_TABLE = new Array(256);
      var LOG_TABLE = new Array(256);
      for (var i = 0; i < 8; i += 1) {
        EXP_TABLE[i] = 1 << i;
      }
      for (var i = 8; i < 256; i += 1) {
        EXP_TABLE[i] = EXP_TABLE[i - 4]
          ^ EXP_TABLE[i - 5]
          ^ EXP_TABLE[i - 6]
          ^ EXP_TABLE[i - 8];
      }
      for (var i = 0; i < 255; i += 1) {
        LOG_TABLE[EXP_TABLE[i] ] = i;
      }
      var _this = {};
      _this.glog = function(n) {
        if (n < 1) {
          throw 'glog(' + n + ')';
        }
        return LOG_TABLE[n];
      };
      _this.gexp = function(n) {
        while (n < 0) {
          n += 255;
        }
        while (n >= 256) {
          n -= 255;
        }
        return EXP_TABLE[n];
      };
      return _this;
    }();
    function qrPolynomial(num, shift) {
      if (typeof num.length == 'undefined') {
        throw num.length + '/' + shift;
      }
      var _num = function() {
        var offset = 0;
        while (offset < num.length && num[offset] == 0) {
          offset += 1;
        }
        var _num = new Array(num.length - offset + shift);
        for (var i = 0; i < num.length - offset; i += 1) {
          _num[i] = num[i + offset];
        }
        return _num;
      }();
      var _this = {};
      _this.getAt = function(index) {
        return _num[index];
      };
      _this.getLength = function() {
        return _num.length;
      };
      _this.multiply = function(e) {
        var num = new Array(_this.getLength() + e.getLength() - 1);
        for (var i = 0; i < _this.getLength(); i += 1) {
          for (var j = 0; j < e.getLength(); j += 1) {
            num[i + j] ^= QRMath.gexp(QRMath.glog(_this.getAt(i) ) + QRMath.glog(e.getAt(j) ) );
          }
        }
        return qrPolynomial(num, 0);
      };
      _this.mod = function(e) {
        if (_this.getLength() - e.getLength() < 0) {
          return _this;
        }
        var ratio = QRMath.glog(_this.getAt(0) ) - QRMath.glog(e.getAt(0) );
        var num = new Array(_this.getLength() );
        for (var i = 0; i < _this.getLength(); i += 1) {
          num[i] = _this.getAt(i);
        }
        for (var i = 0; i < e.getLength(); i += 1) {
          num[i] ^= QRMath.gexp(QRMath.glog(e.getAt(i) ) + ratio);
        }
        return qrPolynomial(num, 0).mod(e);
      };
      return _this;
    };
    var QRRSBlock = function() {
      var RS_BLOCK_TABLE = [
        [1, 26, 19],
        [1, 26, 16],
        [1, 26, 13],
        [1, 26, 9],
        [1, 44, 34],
        [1, 44, 28],
        [1, 44, 22],
        [1, 44, 16],
        [1, 70, 55],
        [1, 70, 44],
        [2, 35, 17],
        [2, 35, 13],
        [1, 100, 80],
        [2, 50, 32],
        [2, 50, 24],
        [4, 25, 9],
        [1, 134, 108],
        [2, 67, 43],
        [2, 33, 15, 2, 34, 16],
        [2, 33, 11, 2, 34, 12],
        [2, 86, 68],
        [4, 43, 27],
        [4, 43, 19],
        [4, 43, 15],
        [2, 98, 78],
        [4, 49, 31],
        [2, 32, 14, 4, 33, 15],
        [4, 39, 13, 1, 40, 14],
        [2, 121, 97],
        [2, 60, 38, 2, 61, 39],
        [4, 40, 18, 2, 41, 19],
        [4, 40, 14, 2, 41, 15],
        [2, 146, 116],
        [3, 58, 36, 2, 59, 37],
        [4, 36, 16, 4, 37, 17],
        [4, 36, 12, 4, 37, 13],
        [2, 86, 68, 2, 87, 69],
        [4, 69, 43, 1, 70, 44],
        [6, 43, 19, 2, 44, 20],
        [6, 43, 15, 2, 44, 16],
        [4, 101, 81],
        [1, 80, 50, 4, 81, 51],
        [4, 50, 22, 4, 51, 23],
        [3, 36, 12, 8, 37, 13],
        [2, 116, 92, 2, 117, 93],
        [6, 58, 36, 2, 59, 37],
        [4, 46, 20, 6, 47, 21],
        [7, 42, 14, 4, 43, 15],
        [4, 133, 107],
        [8, 59, 37, 1, 60, 38],
        [8, 44, 20, 4, 45, 21],
        [12, 33, 11, 4, 34, 12],
        [3, 145, 115, 1, 146, 116],
        [4, 64, 40, 5, 65, 41],
        [11, 36, 16, 5, 37, 17],
        [11, 36, 12, 5, 37, 13],
        [5, 109, 87, 1, 110, 88],
        [5, 65, 41, 5, 66, 42],
        [5, 54, 24, 7, 55, 25],
        [11, 36, 12, 7, 37, 13],
        [5, 122, 98, 1, 123, 99],
        [7, 73, 45, 3, 74, 46],
        [15, 43, 19, 2, 44, 20],
        [3, 45, 15, 13, 46, 16],
        [1, 135, 107, 5, 136, 108],
        [10, 74, 46, 1, 75, 47],
        [1, 50, 22, 15, 51, 23],
        [2, 42, 14, 17, 43, 15],
        [5, 150, 120, 1, 151, 121],
        [9, 69, 43, 4, 70, 44],
        [17, 50, 22, 1, 51, 23],
        [2, 42, 14, 19, 43, 15],
        [3, 141, 113, 4, 142, 114],
        [3, 70, 44, 11, 71, 45],
        [17, 47, 21, 4, 48, 22],
        [9, 39, 13, 16, 40, 14],
        [3, 135, 107, 5, 136, 108],
        [3, 67, 41, 13, 68, 42],
        [15, 54, 24, 5, 55, 25],
        [15, 43, 15, 10, 44, 16],
        [4, 144, 116, 4, 145, 117],
        [17, 68, 42],
        [17, 50, 22, 6, 51, 23],
        [19, 46, 16, 6, 47, 17],
        [2, 139, 111, 7, 140, 112],
        [17, 74, 46],
        [7, 54, 24, 16, 55, 25],
        [34, 37, 13],
        [4, 151, 121, 5, 152, 122],
        [4, 75, 47, 14, 76, 48],
        [11, 54, 24, 14, 55, 25],
        [16, 45, 15, 14, 46, 16],
        [6, 147, 117, 4, 148, 118],
        [6, 73, 45, 14, 74, 46],
        [11, 54, 24, 16, 55, 25],
        [30, 46, 16, 2, 47, 17],
        [8, 132, 106, 4, 133, 107],
        [8, 75, 47, 13, 76, 48],
        [7, 54, 24, 22, 55, 25],
        [22, 45, 15, 13, 46, 16],
        [10, 142, 114, 2, 143, 115],
        [19, 74, 46, 4, 75, 47],
        [28, 50, 22, 6, 51, 23],
        [33, 46, 16, 4, 47, 17],
        [8, 152, 122, 4, 153, 123],
        [22, 73, 45, 3, 74, 46],
        [8, 53, 23, 26, 54, 24],
        [12, 45, 15, 28, 46, 16],
        [3, 147, 117, 10, 148, 118],
        [3, 73, 45, 23, 74, 46],
        [4, 54, 24, 31, 55, 25],
        [11, 45, 15, 31, 46, 16],
        [7, 146, 116, 7, 147, 117],
        [21, 73, 45, 7, 74, 46],
        [1, 53, 23, 37, 54, 24],
        [19, 45, 15, 26, 46, 16],
        [5, 145, 115, 10, 146, 116],
        [19, 75, 47, 10, 76, 48],
        [15, 54, 24, 25, 55, 25],
        [23, 45, 15, 25, 46, 16],
        [13, 145, 115, 3, 146, 116],
        [2, 74, 46, 29, 75, 47],
        [42, 54, 24, 1, 55, 25],
        [23, 45, 15, 28, 46, 16],
        [17, 145, 115],
        [10, 74, 46, 23, 75, 47],
        [10, 54, 24, 35, 55, 25],
        [19, 45, 15, 35, 46, 16],
        [17, 145, 115, 1, 146, 116],
        [14, 74, 46, 21, 75, 47],
        [29, 54, 24, 19, 55, 25],
        [11, 45, 15, 46, 46, 16],
        [13, 145, 115, 6, 146, 116],
        [14, 74, 46, 23, 75, 47],
        [44, 54, 24, 7, 55, 25],
        [59, 46, 16, 1, 47, 17],
        [12, 151, 121, 7, 152, 122],
        [12, 75, 47, 26, 76, 48],
        [39, 54, 24, 14, 55, 25],
        [22, 45, 15, 41, 46, 16],
        [6, 151, 121, 14, 152, 122],
        [6, 75, 47, 34, 76, 48],
        [46, 54, 24, 10, 55, 25],
        [2, 45, 15, 64, 46, 16],
        [17, 152, 122, 4, 153, 123],
        [29, 74, 46, 14, 75, 47],
        [49, 54, 24, 10, 55, 25],
        [24, 45, 15, 46, 46, 16],
        [4, 152, 122, 18, 153, 123],
        [13, 74, 46, 32, 75, 47],
        [48, 54, 24, 14, 55, 25],
        [42, 45, 15, 32, 46, 16],
        [20, 147, 117, 4, 148, 118],
        [40, 75, 47, 7, 76, 48],
        [43, 54, 24, 22, 55, 25],
        [10, 45, 15, 67, 46, 16],
        [19, 148, 118, 6, 149, 119],
        [18, 75, 47, 31, 76, 48],
        [34, 54, 24, 34, 55, 25],
        [20, 45, 15, 61, 46, 16]
      ];
      var qrRSBlock = function(totalCount, dataCount) {
        var _this = {};
        _this.totalCount = totalCount;
        _this.dataCount = dataCount;
        return _this;
      };
      var _this = {};
      var getRsBlockTable = function(typeNumber, errorCorrectionLevel) {
        switch(errorCorrectionLevel) {
        case QRErrorCorrectionLevel.L :
          return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 0];
        case QRErrorCorrectionLevel.M :
          return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 1];
        case QRErrorCorrectionLevel.Q :
          return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 2];
        case QRErrorCorrectionLevel.H :
          return RS_BLOCK_TABLE[(typeNumber - 1) * 4 + 3];
        default :
          return undefined;
        }
      };
      _this.getRSBlocks = function(typeNumber, errorCorrectionLevel) {
        var rsBlock = getRsBlockTable(typeNumber, errorCorrectionLevel);
        if (typeof rsBlock == 'undefined') {
          throw 'bad rs block @ typeNumber:' + typeNumber +
              '/errorCorrectionLevel:' + errorCorrectionLevel;
        }
        var length = rsBlock.length / 3;
        var list = [];
        for (var i = 0; i < length; i += 1) {
          var count = rsBlock[i * 3 + 0];
          var totalCount = rsBlock[i * 3 + 1];
          var dataCount = rsBlock[i * 3 + 2];
          for (var j = 0; j < count; j += 1) {
            list.push(qrRSBlock(totalCount, dataCount) );
          }
        }
        return list;
      };
      return _this;
    }();
    var qrBitBuffer = function() {
      var _buffer = [];
      var _length = 0;
      var _this = {};
      _this.getBuffer = function() {
        return _buffer;
      };
      _this.getAt = function(index) {
        var bufIndex = Math.floor(index / 8);
        return ( (_buffer[bufIndex] >>> (7 - index % 8) ) & 1) == 1;
      };
      _this.put = function(num, length) {
        for (var i = 0; i < length; i += 1) {
          _this.putBit( ( (num >>> (length - i - 1) ) & 1) == 1);
        }
      };
      _this.getLengthInBits = function() {
        return _length;
      };
      _this.putBit = function(bit) {
        var bufIndex = Math.floor(_length / 8);
        if (_buffer.length <= bufIndex) {
          _buffer.push(0);
        }
        if (bit) {
          _buffer[bufIndex] |= (0x80 >>> (_length % 8) );
        }
        _length += 1;
      };
      return _this;
    };
    var qrNumber = function(data) {
      var _mode = QRMode.MODE_NUMBER;
      var _data = data;
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return _data.length;
      };
      _this.write = function(buffer) {
        var data = _data;
        var i = 0;
        while (i + 2 < data.length) {
          buffer.put(strToNum(data.substring(i, i + 3) ), 10);
          i += 3;
        }
        if (i < data.length) {
          if (data.length - i == 1) {
            buffer.put(strToNum(data.substring(i, i + 1) ), 4);
          } else if (data.length - i == 2) {
            buffer.put(strToNum(data.substring(i, i + 2) ), 7);
          }
        }
      };
      var strToNum = function(s) {
        var num = 0;
        for (var i = 0; i < s.length; i += 1) {
          num = num * 10 + chatToNum(s.charAt(i) );
        }
        return num;
      };
      var chatToNum = function(c) {
        if ('0' <= c && c <= '9') {
          return c.charCodeAt(0) - '0'.charCodeAt(0);
        }
        throw 'illegal char :' + c;
      };
      return _this;
    };
    var qrAlphaNum = function(data) {
      var _mode = QRMode.MODE_ALPHA_NUM;
      var _data = data;
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return _data.length;
      };
      _this.write = function(buffer) {
        var s = _data;
        var i = 0;
        while (i + 1 < s.length) {
          buffer.put(
            getCode(s.charAt(i) ) * 45 +
            getCode(s.charAt(i + 1) ), 11);
          i += 2;
        }
        if (i < s.length) {
          buffer.put(getCode(s.charAt(i) ), 6);
        }
      };
      var getCode = function(c) {
        if ('0' <= c && c <= '9') {
          return c.charCodeAt(0) - '0'.charCodeAt(0);
        } else if ('A' <= c && c <= 'Z') {
          return c.charCodeAt(0) - 'A'.charCodeAt(0) + 10;
        } else {
          switch (c) {
          case ' ' : return 36;
          case '$' : return 37;
          case '%' : return 38;
          case '*' : return 39;
          case '+' : return 40;
          case '-' : return 41;
          case '.' : return 42;
          case '/' : return 43;
          case ':' : return 44;
          default :
            throw 'illegal char :' + c;
          }
        }
      };
      return _this;
    };
    var qr8BitByte = function(data) {
      var _mode = QRMode.MODE_8BIT_BYTE;
      var _data = data;
      var _bytes = qrcode.stringToBytes(data);
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return _bytes.length;
      };
      _this.write = function(buffer) {
        for (var i = 0; i < _bytes.length; i += 1) {
          buffer.put(_bytes[i], 8);
        }
      };
      return _this;
    };
    var qrKanji = function(data) {
      var _mode = QRMode.MODE_KANJI;
      var _data = data;
      var stringToBytes = qrcode.stringToBytesFuncs['SJIS'];
      if (!stringToBytes) {
        throw 'sjis not supported.';
      }
      !function(c, code) {
        var test = stringToBytes(c);
        if (test.length != 2 || ( (test[0] << 8) | test[1]) != code) {
          throw 'sjis not supported.';
        }
      }('\u53cb', 0x9746);
      var _bytes = stringToBytes(data);
      var _this = {};
      _this.getMode = function() {
        return _mode;
      };
      _this.getLength = function(buffer) {
        return ~~(_bytes.length / 2);
      };
      _this.write = function(buffer) {
        var data = _bytes;
        var i = 0;
        while (i + 1 < data.length) {
          var c = ( (0xff & data[i]) << 8) | (0xff & data[i + 1]);
          if (0x8140 <= c && c <= 0x9FFC) {
            c -= 0x8140;
          } else if (0xE040 <= c && c <= 0xEBBF) {
            c -= 0xC140;
          } else {
            throw 'illegal char at ' + (i + 1) + '/' + c;
          }
          c = ( (c >>> 8) & 0xff) * 0xC0 + (c & 0xff);
          buffer.put(c, 13);
          i += 2;
        }
        if (i < data.length) {
          throw 'illegal char at ' + (i + 1);
        }
      };
      return _this;
    };
    var byteArrayOutputStream = function() {
      var _bytes = [];
      var _this = {};
      _this.writeByte = function(b) {
        _bytes.push(b & 0xff);
      };
      _this.writeShort = function(i) {
        _this.writeByte(i);
        _this.writeByte(i >>> 8);
      };
      _this.writeBytes = function(b, off, len) {
        off = off || 0;
        len = len || b.length;
        for (var i = 0; i < len; i += 1) {
          _this.writeByte(b[i + off]);
        }
      };
      _this.writeString = function(s) {
        for (var i = 0; i < s.length; i += 1) {
          _this.writeByte(s.charCodeAt(i) );
        }
      };
      _this.toByteArray = function() {
        return _bytes;
      };
      _this.toString = function() {
        var s = '';
        s += '[';
        for (var i = 0; i < _bytes.length; i += 1) {
          if (i > 0) {
            s += ',';
          }
          s += _bytes[i];
        }
        s += ']';
        return s;
      };
      return _this;
    };
    var base64EncodeOutputStream = function() {
      var _buffer = 0;
      var _buflen = 0;
      var _length = 0;
      var _base64 = '';
      var _this = {};
      var writeEncoded = function(b) {
        _base64 += String.fromCharCode(encode(b & 0x3f) );
      };
      var encode = function(n) {
        if (n < 0) {
        } else if (n < 26) {
          return 0x41 + n;
        } else if (n < 52) {
          return 0x61 + (n - 26);
        } else if (n < 62) {
          return 0x30 + (n - 52);
        } else if (n == 62) {
          return 0x2b;
        } else if (n == 63) {
          return 0x2f;
        }
        throw 'n:' + n;
      };
      _this.writeByte = function(n) {
        _buffer = (_buffer << 8) | (n & 0xff);
        _buflen += 8;
        _length += 1;
        while (_buflen >= 6) {
          writeEncoded(_buffer >>> (_buflen - 6) );
          _buflen -= 6;
        }
      };
      _this.flush = function() {
        if (_buflen > 0) {
          writeEncoded(_buffer << (6 - _buflen) );
          _buffer = 0;
          _buflen = 0;
        }
        if (_length % 3 != 0) {
          var padlen = 3 - _length % 3;
          for (var i = 0; i < padlen; i += 1) {
            _base64 += '=';
          }
        }
      };
      _this.toString = function() {
        return _base64;
      };
      return _this;
    };
    var base64DecodeInputStream = function(str) {
      var _str = str;
      var _pos = 0;
      var _buffer = 0;
      var _buflen = 0;
      var _this = {};
      _this.read = function() {
        while (_buflen < 8) {
          if (_pos >= _str.length) {
            if (_buflen == 0) {
              return -1;
            }
            throw 'unexpected end of file./' + _buflen;
          }
          var c = _str.charAt(_pos);
          _pos += 1;
          if (c == '=') {
            _buflen = 0;
            return -1;
          } else if (c.match(/^\s$/) ) {
            continue;
          }
          _buffer = (_buffer << 6) | decode(c.charCodeAt(0) );
          _buflen += 6;
        }
        var n = (_buffer >>> (_buflen - 8) ) & 0xff;
        _buflen -= 8;
        return n;
      };
      var decode = function(c) {
        if (0x41 <= c && c <= 0x5a) {
          return c - 0x41;
        } else if (0x61 <= c && c <= 0x7a) {
          return c - 0x61 + 26;
        } else if (0x30 <= c && c <= 0x39) {
          return c - 0x30 + 52;
        } else if (c == 0x2b) {
          return 62;
        } else if (c == 0x2f) {
          return 63;
        } else {
          throw 'c:' + c;
        }
      };
      return _this;
    };
    var gifImage = function(width, height) {
      var _width = width;
      var _height = height;
      var _data = new Array(width * height);
      var _this = {};
      _this.setPixel = function(x, y, pixel) {
        _data[y * _width + x] = pixel;
      };
      _this.write = function(out) {
        out.writeString('GIF87a');
        out.writeShort(_width);
        out.writeShort(_height);
        out.writeByte(0x80); // 2bit
        out.writeByte(0);
        out.writeByte(0);
        out.writeByte(0x00);
        out.writeByte(0x00);
        out.writeByte(0x00);
        out.writeByte(0xff);
        out.writeByte(0xff);
        out.writeByte(0xff);
        out.writeString(',');
        out.writeShort(0);
        out.writeShort(0);
        out.writeShort(_width);
        out.writeShort(_height);
        out.writeByte(0);
        var lzwMinCodeSize = 2;
        var raster = getLZWRaster(lzwMinCodeSize);
        out.writeByte(lzwMinCodeSize);
        var offset = 0;
        while (raster.length - offset > 255) {
          out.writeByte(255);
          out.writeBytes(raster, offset, 255);
          offset += 255;
        }
        out.writeByte(raster.length - offset);
        out.writeBytes(raster, offset, raster.length - offset);
        out.writeByte(0x00);
        out.writeString(';');
      };
      var bitOutputStream = function(out) {
        var _out = out;
        var _bitLength = 0;
        var _bitBuffer = 0;
        var _this = {};
        _this.write = function(data, length) {
          if ( (data >>> length) != 0) {
            throw 'length over';
          }
          while (_bitLength + length >= 8) {
            _out.writeByte(0xff & ( (data << _bitLength) | _bitBuffer) );
            length -= (8 - _bitLength);
            data >>>= (8 - _bitLength);
            _bitBuffer = 0;
            _bitLength = 0;
          }
          _bitBuffer = (data << _bitLength) | _bitBuffer;
          _bitLength = _bitLength + length;
        };
        _this.flush = function() {
          if (_bitLength > 0) {
            _out.writeByte(_bitBuffer);
          }
        };
        return _this;
      };
      var getLZWRaster = function(lzwMinCodeSize) {
        var clearCode = 1 << lzwMinCodeSize;
        var endCode = (1 << lzwMinCodeSize) + 1;
        var bitLength = lzwMinCodeSize + 1;
        var table = lzwTable();
        for (var i = 0; i < clearCode; i += 1) {
          table.add(String.fromCharCode(i) );
        }
        table.add(String.fromCharCode(clearCode) );
        table.add(String.fromCharCode(endCode) );
        var byteOut = byteArrayOutputStream();
        var bitOut = bitOutputStream(byteOut);
        bitOut.write(clearCode, bitLength);
        var dataIndex = 0;
        var s = String.fromCharCode(_data[dataIndex]);
        dataIndex += 1;
        while (dataIndex < _data.length) {
          var c = String.fromCharCode(_data[dataIndex]);
          dataIndex += 1;
          if (table.contains(s + c) ) {
            s = s + c;
          } else {
            bitOut.write(table.indexOf(s), bitLength);
            if (table.size() < 0xfff) {
              if (table.size() == (1 << bitLength) ) {
                bitLength += 1;
              }
              table.add(s + c);
            }
            s = c;
          }
        }
        bitOut.write(table.indexOf(s), bitLength);
        bitOut.write(endCode, bitLength);
        bitOut.flush();
        return byteOut.toByteArray();
      };
      var lzwTable = function() {
        var _map = {};
        var _size = 0;
        var _this = {};
        _this.add = function(key) {
          if (_this.contains(key) ) {
            throw 'dup key:' + key;
          }
          _map[key] = _size;
          _size += 1;
        };
        _this.size = function() {
          return _size;
        };
        _this.indexOf = function(key) {
          return _map[key];
        };
        _this.contains = function(key) {
          return typeof _map[key] != 'undefined';
        };
        return _this;
      };
      return _this;
    };
    var createDataURL = function(width, height, getPixel) {
      var gif = gifImage(width, height);
      for (var y = 0; y < height; y += 1) {
        for (var x = 0; x < width; x += 1) {
          gif.setPixel(x, y, getPixel(x, y) );
        }
      }
      var b = byteArrayOutputStream();
      gif.write(b);
      var base64 = base64EncodeOutputStream();
      var bytes = b.toByteArray();
      for (var i = 0; i < bytes.length; i += 1) {
        base64.writeByte(bytes[i]);
      }
      base64.flush();
      return 'data:image/gif;base64,' + base64;
    };
    return qrcode;
  }();
  !function() {
    qrcode.stringToBytesFuncs['UTF-8'] = function(s) {
      function toUTF8Array(str) {
        var utf8 = [];
        for (var i=0; i < str.length; i++) {
          var charcode = str.charCodeAt(i);
          if (charcode < 0x80) utf8.push(charcode);
          else if (charcode < 0x800) {
            utf8.push(0xc0 | (charcode >> 6),
                0x80 | (charcode & 0x3f));
          }
          else if (charcode < 0xd800 || charcode >= 0xe000) {
            utf8.push(0xe0 | (charcode >> 12),
                0x80 | ((charcode>>6) & 0x3f),
                0x80 | (charcode & 0x3f));
          }
          else {
            i++;
            charcode = 0x10000 + (((charcode & 0x3ff)<<10)
              | (str.charCodeAt(i) & 0x3ff));
            utf8.push(0xf0 | (charcode >>18),
                0x80 | ((charcode>>12) & 0x3f),
                0x80 | ((charcode>>6) & 0x3f),
                0x80 | (charcode & 0x3f));
          }
        }
        return utf8;
      }
      return toUTF8Array(s);
    };
  }();
  qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
  // 返回二维码方阵（true = 黑块）；内容太长时抛出错误。
  function qrMatrix(text) {
    var q;
    try { q = qrcode(0, 'M'); q.addData(String(text)); q.make(); }
    catch (e) { q = qrcode(0, 'L'); q.addData(String(text)); q.make(); }
    var size = q.getModuleCount(), rows = [];
    for (var r = 0; r < size; r++) { var row = []; for (var c = 0; c < size; c++) row.push(q.isDark(r, c)); rows.push(row); }
    return rows;
  }

  var api = {
    parseVless: parseVless, parseNodeLink: parseNodeLink, importLinks: importLinks, isSubscriptionNodeExcluded: isSubscriptionNodeExcluded, excludeSubscriptionNode: excludeSubscriptionNode, excludedNodePattern: excludedNodePattern, exitReferences: exitReferences, removeExit: removeExit, BLOCKED_EXIT: BLOCKED_EXIT, makeSub: makeSub, makeExit: makeExit, makeRule: makeRule, makeDevice: makeDevice, memberName: memberName,
    parseFinalExit: parseFinalExit, defaultExitTarget: defaultExitTarget, ruleLine: ruleLine, genYaml: genYaml, nameTaken: nameTaken, uniqueName: uniqueName, chainChecks: chainChecks, SUB_HOURS: SUB_HOURS,
    nodeLink: nodeLink, qrMatrix: qrMatrix
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.PanelLib = api;
})(typeof self !== 'undefined' ? self : this);
