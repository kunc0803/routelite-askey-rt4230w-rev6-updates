#!/bin/sh
# 在已有面板上更新程序文件，由 Mac 上传后调用。
set -eu
umask 077
stage=$1
base=${PANEL_DIR:-/etc/clashpanel}
oc=${OC_DIR:-/etc/openclash}
# New factory default is 9527. Preserve an existing device's configured port.
panel_port=${PANEL_PORT:-}
if [ -z "$panel_port" ]; then
  conf=${PANEL_NGINX_CONF:-/etc/nginx/conf.d/clashpanel.conf}
  if [ -f "$conf" ]; then panel_port=$(awk '$1=="listen" {gsub(/;/,"",$2);if($2 ~ /^[0-9]+$/){print $2;exit}}' "$conf"); fi
fi
panel_port=${panel_port:-9527}
case "$panel_port" in *[!0-9]*|'') echo '面板端口无效' >&2; exit 1;; esac
[ "$panel_port" -ge 1 ] && [ "$panel_port" -le 65535 ] || exit 1
test -f "$base/api.sh"
if [ "$base" = /etc/clashpanel ]; then
  [ "$(cat /tmp/sysinfo/board_name)" = "askey,rt4230w-rev6" ] || { echo "本升级包不适用于该硬件" >&2; exit 1; }
fi
command -v flock >/dev/null
command -v curl >/dev/null
command -v ruby >/dev/null
exec 9>"$base/write.lock"
flock -n 9 || { echo '设置正在保存或应用，请稍后重试。' >&2; exit 1; }
cd "$stage"
sha256sum -c SHA256SUMS
files="www/index.html www/lib.js www/presets.js www/guide.html api.sh reset.sh ipv4-only.sh merge.rb iot-network.sh guest-network.sh update.sh update-sources admin-password.rb wifi24.rb VERSION"
snapshot() {
  for file in "$base/state.json" "$base/panel.yaml" "$base/generation" "$oc/config/panel.yaml" "$oc/panel.yaml"; do
    if [ -f "$file" ]; then sha256sum "$file"; else printf 'missing %s\n' "$file"; fi
  done
}
before=$(snapshot)
core=$(pidof clash || true)
backup=$(mktemp -d "$base/backup/github-update-XXXXXX")
for file in $files; do
  mkdir -p "$backup/$(dirname "$file")"
  [ ! -f "$base/$file" ] || cp -p "$base/$file" "$backup/$file"
done
replace() {
  cp "$1" "$2.new"
  chmod 644 "$2.new"
  case "$2" in *.sh|*.rb) chmod 755 "$2.new";; esac
  mv "$2.new" "$2"
}
rollback() {
  trap - EXIT HUP INT TERM
  for file in $files; do
    if [ -f "$backup/$file" ]; then replace "$backup/$file" "$base/$file"; else rm -f "$base/$file"; fi
  done
  echo '升级未完成，已恢复旧面板程序。' >&2
}
trap rollback EXIT
trap 'exit 1' HUP INT TERM
# 最后更新页面入口，减少新旧文件同时出现的窗口。
for file in iot-network.sh guest-network.sh update.sh update-sources admin-password.rb wifi24.rb merge.rb reset.sh ipv4-only.sh api.sh www/lib.js www/presets.js www/guide.html VERSION www/index.html; do
  replace "$stage/$file" "$base/$file"
done
for file in index.html lib.js presets.js guide.html; do
  curl -fsS --max-time 8 "http://127.0.0.1:$panel_port/$file" -o "$stage/http-check"
  test "$(sha256sum "$stage/http-check" | cut -d ' ' -f1)" = "$(sha256sum "$stage/www/$file" | cut -d ' ' -f1)"
done
test "$(snapshot)" = "$before"
test "$(pidof clash || true)" = "$core"
trap - EXIT HUP INT TERM
printf '面板版本 %s 已升级，备份 %s。请刷新浏览器。\n' "$(cat "$base/VERSION")" "$backup"
