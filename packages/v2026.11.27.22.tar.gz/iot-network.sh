#!/bin/sh
# 2.4GHz smart-home AP -> one isolated direct network; no new proxy/DNS daemon.
# Since r6 the firmware's first boot runs "factory"; "install" converts an older router in place.
set -eu
D=${PANEL_DIR:-/etc/clashpanel}
subnet=10.24.24.0/24
runtime() {
  # OpenClash calls this AFTER building its chains. Put bypass before fake-IP/DNS interception.
  for chain in openclash openclash_mangle openclash_dns_redirect; do
    if nft list chain inet fw4 "$chain" >/dev/null 2>&1; then
      nft -a list chain inet fw4 "$chain" | sed -n '/comment "RouteLite IoT bypass"/s/.*# handle //p' | while read -r handle; do nft delete rule inet fw4 "$chain" handle "$handle"; done
      nft insert rule inet fw4 "$chain" iifname br-iot counter return comment '"RouteLite IoT bypass"'
    fi
  done
  # Some OpenClash versions insert DNS hijack directly into dstnat.
  if nft list chain inet fw4 dstnat >/dev/null 2>&1; then
    nft -a list chain inet fw4 dstnat | sed -n '/comment "RouteLite IoT bypass"/s/.*# handle //p' | while read -r handle; do nft delete rule inet fw4 dstnat handle "$handle"; done
    nft insert rule inet fw4 dstnat iifname br-iot counter return comment '"RouteLite IoT bypass"'
  fi
}
dns_update() {
  # Only actual upstream resolvers; never advertise the main network's proxy DNS.
  servers=$(ubus call network.interface.wan status 2>/dev/null | jsonfilter -e '@["dns-server"][*]' | awk '/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ && $0 !~ /^127\./ && $0 !~ /^198\.1[89]\./ {if(n++)printf ",";printf "%s",$0}')
  # Offline provisioning has no DHCP WAN lease yet; replaced on the next WAN ifup/update.
  [ -n "$servers" ] || servers=119.29.29.29
  desired="6,$servers"
  [ "$(uci -q get dhcp.routelite_iot.dhcp_option || true)" = "$desired" ] && return 0
  uci -q delete dhcp.routelite_iot.dhcp_option || true
  uci add_list "dhcp.routelite_iot.dhcp_option=$desired"
  uci commit dhcp
  [ "${DNS_NO_RELOAD:-0}" = 1 ] || /etc/init.d/dnsmasq reload
}
iot_uci() {
  # Network, DHCP pool and firewall isolation of the smart-home network (no commit here).
  uci -q batch <<'UCI'
set network.routelite_iot_dev=device
set network.routelite_iot_dev.name='br-iot'
set network.routelite_iot_dev.type='bridge'
set network.routelite_iot=interface
set network.routelite_iot.device='br-iot'
set network.routelite_iot.proto='static'
set network.routelite_iot.ipaddr='10.24.24.1'
set network.routelite_iot.netmask='255.255.255.0'
set network.routelite_iot.delegate='0'
set dhcp.routelite_iot=dhcp
set dhcp.routelite_iot.interface='routelite_iot'
set dhcp.routelite_iot.start='100'
set dhcp.routelite_iot.limit='100'
set dhcp.routelite_iot.leasetime='12h'
set dhcp.routelite_iot.ra='disabled'
set dhcp.routelite_iot.dhcpv6='disabled'
set dhcp.routelite_iot.ndp='disabled'
set firewall.routelite_iot=zone
set firewall.routelite_iot.name='iot'
set firewall.routelite_iot.network='routelite_iot'
set firewall.routelite_iot.input='REJECT'
set firewall.routelite_iot.output='ACCEPT'
set firewall.routelite_iot.forward='REJECT'
set firewall.routelite_iot_dhcp=rule
set firewall.routelite_iot_dhcp.name='IoT DHCP only'
set firewall.routelite_iot_dhcp.src='iot'
set firewall.routelite_iot_dhcp.proto='udp'
set firewall.routelite_iot_dhcp.dest_port='67'
set firewall.routelite_iot_dhcp.family='ipv4'
set firewall.routelite_iot_dhcp.target='ACCEPT'
set firewall.routelite_iot_dns=rule
set firewall.routelite_iot_dns.name='IoT upstream DNS'
set firewall.routelite_iot_dns.src='iot'
set firewall.routelite_iot_dns.dest='wan'
set firewall.routelite_iot_dns.proto='tcp udp'
set firewall.routelite_iot_dns.dest_port='53'
set firewall.routelite_iot_dns.family='ipv4'
set firewall.routelite_iot_dns.target='ACCEPT'
reorder firewall.routelite_iot_dns=0
set firewall.routelite_iot_private=rule
set firewall.routelite_iot_private.name='IoT block private networks'
set firewall.routelite_iot_private.src='iot'
set firewall.routelite_iot_private.dest='*'
set firewall.routelite_iot_private.proto='all'
set firewall.routelite_iot_private.family='ipv4'
set firewall.routelite_iot_private.target='REJECT'
set firewall.routelite_iot_private.dest_ip='10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 169.254.0.0/16 198.18.0.0/15'
set firewall.routelite_iot_wan=forwarding
set firewall.routelite_iot_wan.src='iot'
set firewall.routelite_iot_wan.dest='wan'
set firewall.routelite_lan_iot=rule
set firewall.routelite_lan_iot.name='Main network cannot access IoT'
set firewall.routelite_lan_iot.src='lan'
set firewall.routelite_lan_iot.dest='iot'
set firewall.routelite_lan_iot.proto='all'
set firewall.routelite_lan_iot.target='REJECT'
UCI
}
case "${1:-check}" in
 runtime) [ -f "$D/iot-enabled" ] && runtime; exit 0;;
 dns) [ -f "$D/iot-enabled" ] && dns_update; exit 0;;
 check) [ "$(uci -q get network.routelite_iot.ipaddr || true)" = 10.24.24.1 ] && [ "$(uci -q get wireless.default_radio0.network || true)" = routelite_iot ]; exit $?;;
 install) :;;
 # First boot (r6): network ready from the start, 2.4GHz Wi-Fi itself stays off.
 # The caller binds the 2.4GHz AP to routelite_iot and commits; hooks ship in the firmware.
 factory) iot_uci; touch "$D/iot-enabled"; DNS_NO_RELOAD=1 dns_update; exit 0;;
 *) exit 1;;
esac
[ "$(cat /tmp/sysinfo/board_name)" = xiaomi,mi-router-cr660x ]
[ "$(uci -q get wireless.radio0.band)" = 2g ]
[ "$(uci -q get wireless.default_radio0.device)" = radio0 ]
[ "$(uci -q get wireless.default_radio0.mode)" = ap ]
[ "$(uci -q get openclash.config.lan_ac_mode)" = 0 ]
[ -z "$(uci changes)" ] || { echo 'Uncommitted router settings; stopped.' >&2; exit 1; }
# Do not overwrite an unrelated existing interface or overlapping network.
if [ ! -f "$D/iot-enabled" ]; then
  ! uci -q get network.routelite_iot >/dev/null
  ! ip -4 route show table all | grep -q '10\.24\.24\.'
fi
backup=$(mktemp -d "$D/backup/iot-network-XXXXXX")
chmod 700 "$backup"
for config in network wireless dhcp firewall openclash; do cp -p "/etc/config/$config" "$backup/$config"; done
cp -p /etc/openclash/custom/openclash_custom_firewall_rules.sh "$backup/openclash_custom_firewall_rules.sh"
rollback() {
  for config in network wireless dhcp firewall openclash; do cp -p "$backup/$config" "/etc/config/$config"; uci -q revert "$config" || true; done
  cp -p "$backup/openclash_custom_firewall_rules.sh" /etc/openclash/custom/openclash_custom_firewall_rules.sh
}
trap rollback EXIT
iot_uci
uci set wireless.default_radio0.network='routelite_iot'
uci set wireless.default_radio0.isolate='0'
# Keep existing excluded addresses, add this subnet once.
uci -q del_list "openclash.config.lan_ac_black_ips=$subnet" || true
uci add_list "openclash.config.lan_ac_black_ips=$subnet"
fw4 check >/dev/null
for config in network wireless dhcp firewall openclash; do uci commit "$config"; done
hook=/etc/openclash/custom/openclash_custom_firewall_rules.sh
if ! grep -q 'RouteLite isolated IoT' "$hook"; then
  sed '/^exit 0/d' "$hook" > "$hook.new"
  printf '\n# RouteLite isolated IoT\n[ ! -f /etc/clashpanel/iot-enabled ] || sh /etc/clashpanel/iot-network.sh runtime\nexit 0\n' >> "$hook.new"
  chmod 755 "$hook.new"; mv "$hook.new" "$hook"
fi
cat > /etc/hotplug.d/iface/95-routelite-iot <<'HOOK'
#!/bin/sh
[ "$INTERFACE" = wan ] || exit 0
case "$ACTION" in ifup|ifupdate) sh /etc/clashpanel/iot-network.sh dns;; esac
HOOK
chmod 755 /etc/hotplug.d/iface/95-routelite-iot
touch "$D/iot-enabled"
trap - EXIT
DNS_NO_RELOAD=1 dns_update
ubus call network reload >/dev/null
wifi down radio0
wifi up radio0
# This Kwrt build returns nonzero for its pre-existing optional include scripts.
# Accept that only after syntax AND the required active isolation chains are verified.
if ! /etc/init.d/firewall reload >/dev/null; then
  fw4 check >/dev/null
  nft list chain inet fw4 forward_iot | grep -q 'IoT block private networks'
  nft list chain inet fw4 input_iot | grep -q 'reject_from_iot'
  nft list chain inet fw4 forward_lan | grep -q 'Main network cannot access IoT'
fi
/etc/init.d/dnsmasq reload || { sleep 2; /etc/init.d/dnsmasq reload; }
runtime
printf 'IoT network installed. Backup: %s\n' "$backup"
