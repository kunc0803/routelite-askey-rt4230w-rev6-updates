#!/bin/sh
# OpenClash 面板后端：只读写 /etc/clashpanel 和 OpenClash 的 config 目录。
D=${PANEL_DIR:-/etc/clashpanel}
OC=${OC_DIR:-/etc/openclash}
PANEL_CFG=$OC/config/panel.yaml
mkdir -p "$D/backup" 2>/dev/null

QS="${1:-$QUERY_STRING}"
BODYF="$2"
RAW=1   # 经 ubus 调用时不需要 HTTP 头
case "$BODYF" in /tmp/clashpanel-body-*) trap 'rm -f "$BODYF"' EXIT ;; *) [ -z "$BODYF" ] || BODYF="" ;; esac
act=$(printf '%s' "$QS" | sed -n 's/.*action=\([a-z0-9_]*\).*/\1/p')

hdr() { [ -n "$RAW" ] || printf 'Content-Type: application/json; charset=utf-8\r\nCache-Control: no-store\r\n\r\n'; }
ok()  { hdr; printf '{"ok":true%s}' "$1"; }
err() { hdr; printf '{"ok":false,"error":"%s"}' "$1"; exit 0; }

read_body() { # $1 = 目标文件；请求体来自 $BODYF（ubus 调用）或标准输入（本机测试）
  if [ -n "$BODYF" ] && [ -f "$BODYF" ]; then
    [ "$(wc -c < "$BODYF")" -gt 1048576 ] && err "too_large"
    cat "$BODYF" > "$1"
  elif [ -n "$CONTENT_LENGTH" ] && [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
    [ "$CONTENT_LENGTH" -gt 1048576 ] && err "too_large"
    head -c "$CONTENT_LENGTH" > "$1"
  else
    : > "$1"
  fi
}

cfg_path() { uci -q get openclash.config.config_path; }
oc_enabled() { [ "$(uci -q get openclash.config.enable)" = "1" ]; }
oc_running() { pidof clash >/dev/null 2>&1; }
secret() { uci -q get openclash.config.dashboard_password; }
cnport() { p=$(uci -q get openclash.config.cn_port); echo "${p:-9090}"; }

hot_reload() { # 成功返回 0；任何一步失败都还原并返回 1（调用方会改用整套重启）
  [ -f "$D/merge.rb" ] || return 1
  cp "$OC/panel.yaml" "$D/processed.bak" || return 1
  ruby "$D/merge.rb" "$PANEL_CFG" "$OC/panel.yaml" "$D/merged.tmp" >/dev/null 2>&1 || { rm -f "$D/merged.tmp"; return 1; }
  [ -s "$D/merged.tmp" ] || return 1
  mv "$D/merged.tmp" "$OC/panel.yaml"
  printf '{"path":"%s"}' "$OC/panel.yaml" > "$D/reload.json"
  s=$(secret)
  if [ -n "$s" ]; then
    code=$(curl -s -m 45 -o /dev/null -w '%{http_code}' -X PUT -H "Authorization: Bearer $s" -H 'Content-Type: application/json' --data-binary "@$D/reload.json" "http://127.0.0.1:$(cnport)/configs?force=true")
  else
    code=$(curl -s -m 45 -o /dev/null -w '%{http_code}' -X PUT -H 'Content-Type: application/json' --data-binary "@$D/reload.json" "http://127.0.0.1:$(cnport)/configs?force=true")
  fi
  rm -f "$D/reload.json"
  [ "$code" = 204 ] && return 0
  cp "$D/processed.bak" "$OC/panel.yaml" 2>/dev/null
  return 1
}

later() { # 后台执行，让 CGI 立刻返回
  setsid sh -c "sleep 1; $1" 9>&- </dev/null >/dev/null 2>&1 &
}

ipv4_response() {
  awk '
    NR == 1 && /^[[:space:]]*[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+[[:space:]]*$/ {
      line = $0
      gsub(/[[:space:]]/, "", line)
      split(line, octet, ".")
      for (i = 1; i <= 4; i++) if (length(octet[i]) > 3 || octet[i] > 255) exit
      ip = line
    }
    END { if (NR == 1 && ip != "") print ip }
  '
}

proxy_curl_config() {
  # 用运行配置中现有的认证，curl 从标准输入读取，凭据不进入命令行或 API 响应。
  ruby -ryaml -e '
    config = YAML.load_file(ARGV.fetch(0))
    users = Array(config["authentication"])
    auth = users.find { |entry| entry.is_a?(String) && entry.include?(":") && !entry.match?(/[[:cntrl:]]/) }
    abort if !users.empty? && !auth
    if auth
      escaped = auth.gsub(/["\\]/) { |char| "\\" + char }
      puts %q(proxy-user = ") + escaped + %q(")
    end
  ' "$1" 2>/dev/null
}

# 串行化设置写入；清空后拒绝旧页面重新写回旧订阅。
case "$act" in
  save_state|save_yaml|apply|reset|start|stop|wifi24_set|wifi5_set|guest_set|admin_password_set|airports_set|reboot_set|share_set|remote_set|remote_logout|note_add|note_delete)
    exec 9>"$D/write.lock" || err "lock_failed"
    flock -n 9 || err "settings_busy_retry"
    generation=$(cat "$D/generation" 2>/dev/null || printf 0)
    supplied=$(printf '%s' "$QS" | sed -n 's/.*generation=\([a-zA-Z0-9-]*\).*/\1/p')
    [ "$generation" = 0 ] || [ "$supplied" = "$generation" ] || err "settings_reset_reload_page"
    ;;
esac

case "$act" in
  admin_password_set)
    umask 077
    request=$(mktemp /tmp/clashpanel-body-password-XXXXXX) || err "save_failed"
    read_body "$request"
    [ "$(wc -c < "$request")" -le 4096 ] || { rm -f "$request"; err "too_large"; }
    result=$(ruby "$D/admin-password.rb" "$request")
    rm -f "$request"
    hdr; printf '%s' "$result"
    if [ "$(printf '%s' "$result" | jsonfilter -e '@.ok')" = true ]; then
      # Expire root/LuCI/panel web sessions after sending the response; Wi-Fi/core are untouched.
      later "sleep 2; /etc/init.d/rpcd restart"
    fi
    ;;
  update_check|update_status)
    # Online panel update (signed packages, see update.sh). Reading only; no settings lock.
    hdr
    [ -f "$D/update.sh" ] || { printf '{"ok":false,"error":"update_unsupported"}'; exit 0; }
    PANEL_DIR="$D" sh "$D/update.sh" "${act#update_}"
    ;;
  update_start)
    hdr
    [ -f "$D/update.sh" ] || { printf '{"ok":false,"error":"update_unsupported"}'; exit 0; }
    if [ -n "$BODYF" ] && [ -s "$BODYF" ]; then
      [ "$(wc -c < "$BODYF")" -le 4194304 ] || { printf '{"ok":false,"error":"too_large"}'; exit 0; }
      PANEL_DIR="$D" sh "$D/update.sh" start "$BODYF"
    else
      PANEL_DIR="$D" sh "$D/update.sh" start
    fi
    ;;
  airports_get) # 我的机场：机场官网网址收藏。只存名称、网址、用户名，不存密码（交给用户自己的浏览器）。
    hdr
    if [ -s "$D/airports.json" ]; then cat "$D/airports.json"; else printf '{"ok":true,"airports":[]}'; fi
    ;;
  airports_set)
    umask 077
    request=$(mktemp /tmp/clashpanel-body-airports-XXXXXX) || err "save_failed"
    read_body "$request"
    hdr
    ruby -rjson -e '
      def bad(code); raise ArgumentError, code; end
      def text(v, max, code); v = v.to_s.strip; bad(code) if v.length > max || v.match?(/[[:cntrl:]]/); v; end
      begin
        list = JSON.parse(File.read(ARGV[0], encoding: "UTF-8").scrub(""))["airports"]
        bad("airport_bad_data") unless list.is_a?(Array)
        bad("airport_too_many") if list.size > 20
        out = list.map do |a|
          bad("airport_bad_data") unless a.is_a?(Hash)
          name = text(a["name"], 30, "airport_bad_name")
          bad("airport_bad_name") if name.empty?
          url = a["url"].to_s.strip
          url = "https://" + url unless url.match?(%r{\Ahttps?://}i)
          bad("airport_bad_url") unless url.length <= 300 && url.match?(%r{\Ahttps?://[A-Za-z0-9.\-\[\]:]+(?:[/?#][^\s<>"\x27\\]*)?\z}i)
          renew = a["renew"].to_s.strip
          bad("airport_bad_renew") unless renew.empty? || renew.match?(/\A20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\z/)
          { "name" => name, "url" => url, "user" => text(a["user"], 80, "airport_bad_user"), "renew" => renew,
            "quota" => text(a["quota"], 30, "airport_bad_text"), "price" => text(a["price"], 30, "airport_bad_text") }
        end
        json = JSON.generate({ "ok" => true, "airports" => out })
        File.write(ARGV[1], json + "\n")
        print json
      rescue ArgumentError => e
        print JSON.generate({ "ok" => false, "error" => e.message.start_with?("airport_") ? e.message : "airport_bad_data" })
      rescue StandardError
        print JSON.generate({ "ok" => false, "error" => "airport_bad_data" })
      end
    ' "$request" "$D/airports.tmp"
    rm -f "$request"
    [ ! -f "$D/airports.tmp" ] || mv "$D/airports.tmp" "$D/airports.json"
    ;;
  album_status|album_open|album_list) # 相册：只在配置了 U 盘相册（album.conf）且 U 盘已挂载时可用。文件由 nginx 按随机地址直接读写 U 盘。
    hdr
    conf="$D/album.conf"
    root=$(sed -n 's/^ROOT=//p' "$conf" 2>/dev/null | head -1)
    mnt=$(sed -n 's/^MOUNT=//p' "$conf" 2>/dev/null | head -1)
    https=$(sed -n 's/^HTTPS_PORT=//p' "$conf" 2>/dev/null | head -1)
    xfer=$(sed -n 's/^TRANSFER=//p' "$conf" 2>/dev/null | head -1); [ -n "$xfer" ] || [ -z "$mnt" ] || xfer="$mnt/中转"
    ready=false
    if [ -n "$root" ] && [ -n "$mnt" ] && awk -v m="$mnt" '$2 == m { f = 1 } END { exit !f }' "${PROC_MOUNTS:-/proc/mounts}" 2>/dev/null; then ready=true; fi
    if [ "$act" = album_status ]; then
      [ -n "$root" ] || { printf '{"ok":true,"available":false}'; exit 0; }
      ruby -rjson -e 'r, ready, https = ARGV; free = nil
        if ready == "true"; then s = (IO.popen(["df", "-k", File.dirname(r)], &:read).lines.last.split rescue []); free = s[3].to_i * 1024 if s.size > 3; end
        print JSON.generate({ "ok" => true, "available" => true, "mounted" => ready == "true", "transfer" => true, "https_port" => https.to_s.empty? ? nil : https.to_i, "free" => free })' "$root" "$ready" "$https"
      exit 0
    fi
    [ "$ready" = true ] || err "album_not_mounted"
    mkdir -p "$root/.routelite-thumbs" "$root/.routelite-tmp" "$xfer/.routelite-tmp" 2>/dev/null || err "album_not_mounted"
    if [ "$act" = album_open ]; then
      sec="$D/album.secret"; loc=${ALBUM_LOCATIONS:-/etc/nginx/clashpanel.d/album.locations}
      # 随机地址每天换一次：复制出去的链接第二天就失效。
      valid_secret() { printf '%s' "$1" | grep -qE '^[0-9a-f]{32}$'; }
      s=$(cat "$sec" 2>/dev/null)
      if ! valid_secret "$s" || [ -n "$(find "$sec" -mmin +1440 2>/dev/null)" ] || [ ! -s "$loc" ] || ! grep -qF "/album-files/$s/" "$loc" 2>/dev/null || ! grep -qF "/xfer-files/$s/" "$loc" 2>/dev/null; then
        umask 077
        # 内核随机数（所有 OpenWrt 都有）；没有时退回 /dev/urandom。地址不合格就不写 nginx 配置。
        s=$(cat "${UUID_FILE:-/proc/sys/kernel/random/uuid}" "${UUID_FILE:-/proc/sys/kernel/random/uuid}" 2>/dev/null | tr -cd '0-9a-f' | cut -c1-32)
        valid_secret "$s" || s=$(head -c 16 /dev/urandom 2>/dev/null | od -An -tx1 2>/dev/null | tr -cd '0-9a-f')
        valid_secret "$s" || err "album_secret_failed"
        printf '%s' "$s" > "$sec.new" && mv "$sec.new" "$sec"
        mkdir -p "$(dirname "$loc")"
        cat > "$loc.new" <<NGINX
# 由 RouteLite 面板生成（album_open），随机地址每天更换。
location = /album-up/$s/ { return 403; }
location ^~ /album-files/$s/ {
	alias "$root/";
	disable_symlinks on;
	add_header Cache-Control "private, max-age=3600";
}
location ^~ /album-up/$s/ {
	alias "$root/";
	disable_symlinks on;
	limit_except PUT DELETE MKCOL { deny all; }
	dav_methods PUT DELETE MKCOL;
	create_full_put_path off;
	dav_access user:rw group:rw all:rw;
	client_max_body_size 4g;
	client_body_temp_path "$root/.routelite-tmp";
}
# 中转站：U 盘「中转」文件夹，规则和相册一样
location = /xfer-up/$s/ { return 403; }
location ^~ /xfer-files/$s/ {
	alias "$xfer/";
	disable_symlinks on;
	add_header Cache-Control "no-store";
}
location ^~ /xfer-up/$s/ {
	alias "$xfer/";
	disable_symlinks on;
	limit_except PUT DELETE { deny all; }
	dav_methods PUT DELETE;
	create_full_put_path off;
	dav_access user:rw group:rw all:rw;
	client_max_body_size 4g;
	client_body_temp_path "$xfer/.routelite-tmp";
}
NGINX
        chmod 600 "$loc.new"; mv "$loc.new" "$loc"
        ${NGINX_RELOAD:-/etc/init.d/nginx reload} >/dev/null 2>&1
      fi
      valid_secret "$s" || err "album_secret_failed"
      printf '{"ok":true,"files":"/album-files/%s/","up":"/album-up/%s/","xfer_files":"/xfer-files/%s/","xfer_up":"/xfer-up/%s/"}' "$s" "$s" "$s" "$s"
      exit 0
    fi
    request=$(mktemp /tmp/clashpanel-body-album-XXXXXX) || err "save_failed"
    read_body "$request"
    ruby -rjson -rdigest -e '
      IMG = %w[jpg jpeg png heic heif gif webp]; VID = %w[mov mp4 m4v]
      root = File.realpath(ARGV[1].dup.force_encoding("UTF-8"))
      req = (JSON.parse(File.read(ARGV[0], encoding: "UTF-8").scrub("")) rescue {})
      rel = req.is_a?(Hash) ? req["path"].to_s : ""
      rel = rel.split("/").reject { |x| x.empty? || x == "." }
      if rel.any? { |x| x == ".." || x.start_with?(".") }; print JSON.generate({ "ok" => false, "error" => "album_bad_path" }); exit; end
      dir = File.join(root, *rel)
      real = (File.realpath(dir) rescue nil)
      unless real && (real == root || real.start_with?(root + "/")) && File.directory?(real)
        print JSON.generate({ "ok" => false, "error" => "album_bad_path" }); exit
      end
      dirs = []; files = []
      Dir.children(real).each do |name|
        name = name.dup.force_encoding("UTF-8")
        next if name.start_with?(".") || !name.valid_encoding?
        full = File.join(real, name)
        next if File.symlink?(full)
        st = (File.stat(full) rescue next)
        if st.directory?
          dirs << { "name" => name }
        elsif st.file?
          ext = File.extname(name).delete(".").downcase
          kind = IMG.include?(ext) ? "image" : VID.include?(ext) ? "video" : nil
          next unless kind
          relpath = (rel + [name]).join("/")
          key = Digest::SHA1.hexdigest(relpath)
          files << { "name" => name, "size" => st.size, "mtime" => st.mtime.to_i, "kind" => kind, "thumb" => key,
                     "has_thumb" => File.exist?(File.join(root, ".routelite-thumbs", key + ".jpg")) }
        end
      end
      dirs.sort_by! { |d| d["name"] }
      files.sort_by! { |f| [-f["mtime"], f["name"]] }
      print JSON.generate({ "ok" => true, "path" => rel.join("/"), "dirs" => dirs, "files" => files })
    ' "$request" "$root"
    rm -f "$request"
    ;;
  share_get|share_set) # 电脑访问相册（局域网 SMB）：只共享相册文件夹，用户名固定 photos，密码用户自己设。默认关闭。
    hdr
    KSMBD_INIT=${KSMBD_INIT:-/etc/init.d/ksmbd}; KSMBD_DB=${KSMBD_DB:-/etc/ksmbd/ksmbdpwd.db}; SHARE_USER=photos
    root=$(sed -n 's/^ROOT=//p' "$D/album.conf" 2>/dev/null | head -1)
    smnt=$(sed -n 's/^MOUNT=//p' "$D/album.conf" 2>/dev/null | head -1)
    xfer=$(sed -n 's/^TRANSFER=//p' "$D/album.conf" 2>/dev/null | head -1); [ -n "$xfer" ] || [ -z "$smnt" ] || xfer="$smnt/中转"
    [ -n "$root" ] && command -v ksmbd.adduser >/dev/null 2>&1 && [ -x "$KSMBD_INIT" ] || { printf '{"ok":true,"available":false}'; exit 0; }
    share_lockdown() { # 只留相册这一个共享：关掉 Kwrt 的「自动共享整个 U 盘」、访客和老协议
      for sec in $(uci -q show ksmbd | sed -n "s/^ksmbd\.\([^.=]*\)=share$/\1/p"); do
        case "$sec" in routelite_album|routelite_xfer) ;; *) uci -q delete "ksmbd.$sec";; esac
      done
      uci -q batch <<'UCI'
set ksmbd.@globals[0].autoshare='0'
set ksmbd.@globals[0].allow_guest_ipc='0'
set ksmbd.@globals[0].allow_legacy_protocols='0'
set ksmbd.@globals[0].interface='lan'
UCI
    }
    if [ "$act" = share_set ]; then
      request=$(mktemp /tmp/clashpanel-body-share-XXXXXX) || err "save_failed"
      read_body "$request"
      # 密码只经 ruby 以参数数组交给 ksmbd.adduser，不进 shell、不写日志。
      want=$(SHARE_USER=$SHARE_USER KSMBD_DB=$KSMBD_DB ruby -rjson -e '
        req = (JSON.parse(File.read(ARGV[0], encoding: "UTF-8").scrub("")) rescue nil)
        abort "share_bad_data" unless req.is_a?(Hash)
        pw = req["password"].to_s
        unless pw.empty?
          abort "share_bad_password" if pw.length < 8 || pw.length > 64 || pw.match?(/[[:cntrl:]]/)
          db = ENV["KSMBD_DB"]; user = ENV["SHARE_USER"]
          exists = File.exist?(db) && File.foreach(db).any? { |l| l.start_with?(user + ":") }
          system("ksmbd.adduser", "-P", db, exists ? "-u" : "-a", "-p", pw, user, out: File::NULL, err: File::NULL) or abort "share_password_failed"
        end
        print req["enabled"] == true ? "on" : "off"
      ' "$request" 2>&1) || { rm -f "$request"; err "$(printf '%s' "$want" | tail -1 | tr -cd 'a-z_')"; }
      rm -f "$request"
      grep -q "^$SHARE_USER:" "$KSMBD_DB" 2>/dev/null || [ "$want" = off ] || err "share_need_password"
      if [ "$want" = on ]; then
        uci -q batch <<UCI
set ksmbd.routelite_album=share
set ksmbd.routelite_album.name='相册'
set ksmbd.routelite_album.path='$root'
set ksmbd.routelite_album.users='$SHARE_USER'
set ksmbd.routelite_album.read_only='no'
set ksmbd.routelite_album.guest_ok='no'
set ksmbd.routelite_album.browseable='yes'
set ksmbd.routelite_album.hide_dot_files='yes'
set ksmbd.routelite_album.create_mask='0664'
set ksmbd.routelite_album.dir_mask='0775'
set ksmbd.@globals[0].enabled='1'
UCI
        if [ -n "$xfer" ]; then
          mkdir -p "$xfer" 2>/dev/null
          uci -q batch <<UCI
set ksmbd.routelite_xfer=share
set ksmbd.routelite_xfer.name='中转'
set ksmbd.routelite_xfer.path='$xfer'
set ksmbd.routelite_xfer.users='$SHARE_USER'
set ksmbd.routelite_xfer.read_only='no'
set ksmbd.routelite_xfer.guest_ok='no'
set ksmbd.routelite_xfer.browseable='yes'
set ksmbd.routelite_xfer.hide_dot_files='yes'
set ksmbd.routelite_xfer.create_mask='0664'
set ksmbd.routelite_xfer.dir_mask='0775'
UCI
        fi
        share_lockdown
        uci commit ksmbd
        "$KSMBD_INIT" enable >/dev/null 2>&1; "$KSMBD_INIT" restart >/dev/null 2>&1
      else
        uci -q delete ksmbd.routelite_album; uci -q delete ksmbd.routelite_xfer; share_lockdown; uci -q set ksmbd.@globals[0].enabled='0'; uci commit ksmbd
        "$KSMBD_INIT" stop >/dev/null 2>&1; "$KSMBD_INIT" disable >/dev/null 2>&1
      fi
    fi
    enabled=false; uci -q get ksmbd.routelite_album.path >/dev/null 2>&1 && "$KSMBD_INIT" enabled >/dev/null 2>&1 && enabled=true
    has=false; grep -q "^$SHARE_USER:" "$KSMBD_DB" 2>/dev/null && has=true
    printf '{"ok":true,"available":true,"enabled":%s,"user":"%s","has_password":%s,"share":"相册","shares":["相册","中转"]}' "$enabled" "$SHARE_USER" "$has"
    ;;
  remote_get|remote_set|remote_logout) # 远程访问（Tailscale）：默认关闭；开启后在面板点链接登录，手机在外面就能用家里的网络。
    hdr
    TS_INIT=${TS_INIT:-/etc/init.d/tailscale}; RCONF="$D/remote.conf"
    command -v tailscale >/dev/null 2>&1 && [ -x "$TS_INIT" ] || { printf '{"ok":true,"available":false}'; exit 0; }
    ts_ready() { i=0; while [ $i -lt 20 ]; do tailscale status --json >/dev/null 2>&1 && return 0; [ -n "$(tailscale status --json 2>/dev/null)" ] && return 0; i=$((i + 1)); sleep 1; done; return 1; }
    ts_zone() { # tailscale0 进防火墙：可到主网，可经家里宽带上网；不碰智能家居、访客
      uci -q get network.tailscale >/dev/null && return 0
      uci -q batch <<'UCI'
set network.tailscale=interface
set network.tailscale.proto='none'
set network.tailscale.device='tailscale0'
set firewall.routelite_ts=zone
set firewall.routelite_ts.name='tailscale'
set firewall.routelite_ts.network='tailscale'
set firewall.routelite_ts.input='ACCEPT'
set firewall.routelite_ts.output='ACCEPT'
set firewall.routelite_ts.forward='REJECT'
set firewall.routelite_ts_lan=forwarding
set firewall.routelite_ts_lan.src='tailscale'
set firewall.routelite_ts_lan.dest='lan'
set firewall.routelite_ts_wan=forwarding
set firewall.routelite_ts_wan.src='tailscale'
set firewall.routelite_ts_wan.dest='wan'
UCI
      uci commit network; uci commit firewall
      /etc/init.d/firewall reload >/dev/null 2>&1
    }
    if [ "$act" = remote_set ]; then
      request=$(mktemp /tmp/clashpanel-body-remote-XXXXXX) || err "save_failed"
      read_body "$request"
      conf=$(ruby -rjson -e '
        req = (JSON.parse(File.read(ARGV[0], encoding: "UTF-8").scrub("")) rescue nil)
        abort "remote_bad_data" unless req.is_a?(Hash)
        srv = req["server"].to_s.strip.sub(%r{/+\z}, "")
        abort "remote_bad_server" unless srv.empty? || srv.match?(%r{\Ahttps://[A-Za-z0-9.-]+(:[0-9]{1,5})?(/[A-Za-z0-9._~/-]*)?\z})
        puts "ENABLED=" + (req["enabled"] == true ? "1" : "0")
        puts "EXIT=" + (req["exit_node"] == true ? "1" : "0")
        puts "SERVER=" + srv
      ' "$request" 2>&1) || { rm -f "$request"; err "$(printf '%s' "$conf" | tail -1 | tr -cd 'a-z_')"; }
      rm -f "$request"
      umask 077; printf '%s\n' "$conf" > "$RCONF"
    fi
    en=$(sed -n 's/^ENABLED=//p' "$RCONF" 2>/dev/null); ex=$(sed -n 's/^EXIT=//p' "$RCONF" 2>/dev/null); srv=$(sed -n 's/^SERVER=//p' "$RCONF" 2>/dev/null)
    if [ "$act" = remote_logout ]; then
      pidof tailscaled >/dev/null 2>&1 && tailscale logout >/dev/null 2>&1
      printf 'ENABLED=0\nEXIT=%s\nSERVER=%s\n' "${ex:-0}" "$srv" > "$RCONF"; en=0
      "$TS_INIT" stop >/dev/null 2>&1; "$TS_INIT" disable >/dev/null 2>&1
    elif [ "$act" = remote_set ]; then
      if [ "$en" = 1 ]; then
        ts_zone
        "$TS_INIT" enable >/dev/null 2>&1; pidof tailscaled >/dev/null 2>&1 || "$TS_INIT" start >/dev/null 2>&1
        ts_ready || err "remote_start_failed"
        lan=$(uci -q get network.lan.ipaddr); mask=$(uci -q get network.lan.netmask)
        case "$lan" in */*) cidr=$lan;; *) cidr="$lan/${mask:-255.255.255.0}";; esac
        eval "$(ipcalc.sh "$cidr" 2>/dev/null)"
        set -- up --reset --accept-dns=false --hostname=routelite-askey --advertise-routes="${NETWORK:-10.20.20.0}/${PREFIX:-24}"
        [ "$ex" = 1 ] && set -- "$@" --advertise-exit-node
        [ -n "$srv" ] && set -- "$@" --login-server="$srv"
        # 没登录时 up 会一直等，放后台；登录链接从 status 里读。
        setsid tailscale "$@" 9>&- </dev/null >/dev/null 2>&1 &
        sleep 3
      else
        pidof tailscaled >/dev/null 2>&1 && tailscale down >/dev/null 2>&1
        "$TS_INIT" stop >/dev/null 2>&1; "$TS_INIT" disable >/dev/null 2>&1
      fi
    fi
    st=''; pidof tailscaled >/dev/null 2>&1 && st=$(tailscale status --json 2>/dev/null)
    printf '%s' "$st" | ruby -rjson -e '
      s = (JSON.parse(STDIN.read) rescue {}) || {}
      me = s["Self"] || {}
      peers = (s["Peer"] || {}).values.count { |p| p["Online"] }
      print JSON.generate({ "ok" => true, "available" => true, "enabled" => ARGV[0] == "1", "exit_node" => ARGV[1] == "1", "server" => ARGV[2],
        "running" => !s.empty?, "state" => s["BackendState"].to_s, "auth_url" => s["AuthURL"].to_s,
        "ip" => Array(me["TailscaleIPs"]).find { |x| x.include?(".") }.to_s, "name" => me["DNSName"].to_s.sub(/\.\z/, ""), "online_peers" => peers })
    ' "${en:-0}" "${ex:-0}" "$srv"
    ;;
  xfer_list|note_add|note_delete) # 中转站：U 盘「中转」文件夹里的文件 + 文字记事本（.routelite-notes.json，隐藏文件）
    hdr
    conf="$D/album.conf"
    mnt=$(sed -n 's/^MOUNT=//p' "$conf" 2>/dev/null | head -1)
    xfer=$(sed -n 's/^TRANSFER=//p' "$conf" 2>/dev/null | head -1); [ -n "$xfer" ] || [ -z "$mnt" ] || xfer="$mnt/中转"
    [ -n "$xfer" ] && awk -v m="$mnt" '$2 == m { f = 1 } END { exit !f }' "${PROC_MOUNTS:-/proc/mounts}" 2>/dev/null || err "album_not_mounted"
    mkdir -p "$xfer/.routelite-tmp" 2>/dev/null || err "album_not_mounted"
    request=$(mktemp /tmp/clashpanel-body-xfer-XXXXXX) || err "save_failed"
    read_body "$request"
    ruby -rjson -rsecurerandom -e '
      act, dir, req_file = ARGV.map { |x| x.dup.force_encoding("UTF-8") }
      notes_file = File.join(dir, ".routelite-notes.json")
      notes = (JSON.parse(File.read(notes_file, encoding: "UTF-8").scrub("")) rescue [])
      notes = [] unless notes.is_a?(Array)
      req = (JSON.parse(File.read(req_file, encoding: "UTF-8").scrub("")) rescue {}) || {}
      save = lambda do
        tmp = notes_file + ".tmp"
        File.write(tmp, JSON.generate(notes)); File.rename(tmp, notes_file)
      end
      case act
      when "note_add"
        text = req["text"].to_s.gsub("\r\n", "\n").scrub("")
        if text.strip.empty? then print JSON.generate({ "ok" => false, "error" => "note_empty" }); exit; end
        if text.bytesize > 65536 then print JSON.generate({ "ok" => false, "error" => "note_too_long" }); exit; end
        notes.unshift({ "id" => SecureRandom.hex(8), "text" => text, "time" => Time.now.to_i })
        notes = notes.first(200)
        save.call
      when "note_delete"
        id = req["id"].to_s
        notes.reject! { |n| n.is_a?(Hash) && n["id"] == id }
        save.call
      end
      files = []
      Dir.children(dir).each do |name|
        name = name.dup.force_encoding("UTF-8")
        next if name.start_with?(".") || !name.valid_encoding?
        full = File.join(dir, name)
        next if File.symlink?(full)
        st = (File.stat(full) rescue next)
        files << { "name" => name, "size" => st.size, "mtime" => st.mtime.to_i } if st.file?
      end
      files.sort_by! { |f| [-f["mtime"], f["name"]] }
      clean = notes.select { |n| n.is_a?(Hash) && n["id"].is_a?(String) }.map { |n| { "id" => n["id"], "text" => n["text"].to_s, "time" => n["time"].to_i } }
      print JSON.generate({ "ok" => true, "notes" => clean, "files" => files })
    ' "$act" "$xfer" "$request"
    rm -f "$request"
    ;;
  reboot_get) # 定时重启：整台路由器重启（内核、Wi-Fi、代理全部重新开始）。设置就是 crontab 里带标记的一行。
    hdr
    CRONTAB=${ROUTELITE_CRONTAB:-/etc/crontabs/root}
    ruby -rjson -e '
      line, zone, now = ARGV.map { |x| x.dup.force_encoding("UTF-8") }
      m = line.match(/\A(\d+) (\d+) \* \* (\*|[0-6]) /)
      out = { "ok" => true, "enabled" => !m.nil?, "zone" => zone, "now" => now,
              "days" => m ? (m[3] == "*" ? "daily" : m[3]) : "1", "time" => m ? format("%02d:%02d", m[2].to_i, m[1].to_i) : "04:30" }
      print JSON.generate(out)
    ' "$(grep -m1 '# routelite-reboot' "$CRONTAB" 2>/dev/null)" "$(uci -q get system.@system[0].zonename || echo Asia/Shanghai)" "$(date '+%Y-%m-%d %H:%M %w')"
    ;;
  reboot_set)
    umask 077
    CRONTAB=${ROUTELITE_CRONTAB:-/etc/crontabs/root}
    request=$(mktemp /tmp/clashpanel-body-reboot-XXXXXX) || err "save_failed"
    read_body "$request"
    mkdir -p "$(dirname "$CRONTAB")"
    result=$(ruby -rjson -e '
      ZONES = { "Australia/Sydney" => "AEST-10AEDT,M10.1.0,M4.1.0/3", "Asia/Tokyo" => "JST-9", "Asia/Shanghai" => "CST-8", "Asia/Bangkok" => "<+07>-7", "Asia/Dubai" => "<+04>-4", "Europe/Moscow" => "MSK-3", "Europe/Berlin" => "CET-1CEST,M3.5.0,M10.5.0/3", "Europe/London" => "GMT0BST,M3.5.0/1,M10.5.0", "America/New_York" => "EST5EDT,M3.2.0,M11.1.0", "America/Los_Angeles" => "PST8PDT,M3.2.0,M11.1.0" }
      def out(h); print JSON.generate(h); exit; end
      req = (JSON.parse(File.read(ARGV[0], encoding: "UTF-8").scrub("")) rescue nil)
      out("ok" => false, "error" => "reboot_bad_data") unless req.is_a?(Hash)
      zone = req["zone"].to_s
      out("ok" => false, "error" => "reboot_bad_zone") unless ZONES.key?(zone)
      days = req["days"].to_s
      out("ok" => false, "error" => "reboot_bad_days") unless days == "daily" || days.match?(/\A[0-6]\z/)
      t = req["time"].to_s.match(/\A([01]\d|2[0-3]):([0-5]\d)\z/)
      out("ok" => false, "error" => "reboot_bad_time") unless t
      lines = (File.read(ARGV[1], encoding: "UTF-8").scrub("").lines rescue []).reject { |l| l.include?("# routelite-reboot") }
      if req["enabled"] == true
        lines << format("%d %d * * %s ROUTELITE_CRON=1 sh %s/api.sh action=reboot_run >/dev/null 2>&1 # routelite-reboot\n", t[2].to_i, t[1].to_i, days == "daily" ? "*" : days, ARGV[2])
      end
      File.write(ARGV[1] + ".new", lines.join)
      out("ok" => true, "enabled" => req["enabled"] == true, "zone" => zone, "tz" => ZONES[zone], "days" => days, "time" => t[0])
    ' "$request" "$CRONTAB" "$D")
    rm -f "$request"
    hdr
    if [ "$(printf '%s' "$result" | ruby -rjson -e 'print JSON.parse(STDIN.read)["ok"]' 2>/dev/null)" != true ]; then rm -f "$CRONTAB.new"; printf '%s' "$result"; exit 0; fi
    mv "$CRONTAB.new" "$CRONTAB" || err "save_failed"
    zone=$(printf '%s' "$result" | ruby -rjson -e 'h=JSON.parse(STDIN.read); print h["zone"], " ", h["tz"]')
    if [ "$(uci -q get system.@system[0].zonename)" != "${zone%% *}" ]; then
      uci set system.@system[0].zonename="${zone%% *}"; uci set system.@system[0].timezone="${zone#* }"; uci commit system
      [ -x /etc/init.d/system ] && /etc/init.d/system reload >/dev/null 2>&1
    fi
    if [ -x /etc/init.d/cron ]; then /etc/init.d/cron enable >/dev/null 2>&1; /etc/init.d/cron restart >/dev/null 2>&1; fi
    printf '%s' "$result" | ruby -rjson -e 'h=JSON.parse(STDIN.read); h.delete("tz"); h["now"]=ARGV[0]; print JSON.generate(h)' "$(date '+%Y-%m-%d %H:%M %w')"
    ;;
  reboot_run) # 由 crontab 调用，到点直接重启。刚开机不满 15 分钟不重启（防止时钟还没对准时连续重启）。
    [ "${ROUTELITE_CRON:-}" = 1 ] || err "not_allowed"
    up=$(cut -d. -f1 "${UPTIME_FILE:-/proc/uptime}" 2>/dev/null)
    [ "${up:-0}" -ge 900 ] || exit 0
    logger -t routelite "scheduled reboot" 2>/dev/null
    touch "${BANNER:-/etc/banner}" 2>/dev/null; sync
    ${REBOOT_CMD:-reboot}
    ;;
  wifi24_get|wifi5_get|guest_get)
    band=2g; iface=; [ "$act" = wifi24_get ] || band=5g; [ "$act" != guest_get ] || iface=routelite_guest
    hdr
    WIFI_BAND="$band" WIFI_IFACE="$iface" ruby "$D/wifi24.rb" get
    ;;
  wifi24_set|wifi5_set|guest_set)
    band=2g; iface=; [ "$act" = wifi24_set ] || band=5g; [ "$act" != guest_set ] || iface=routelite_guest
    umask 077
    request=$(mktemp /tmp/clashpanel-body-wifi24-XXXXXX) || err "save_failed"
    read_body "$request"
    result=$(WIFI_BAND="$band" WIFI_IFACE="$iface" PANEL_DIR="$D" ruby "$D/wifi24.rb" set "$request")
    rm -f "$request"
    hdr; printf '%s' "$result"
    if [ "$(printf '%s' "$result" | jsonfilter -e '@.changed')" = true ]; then
      radio=$(printf '%s' "$result" | jsonfilter -e '@.radio')
      case "$radio" in *[!A-Za-z0-9_-]*|'') exit 0;; esac
      later "wifi down $radio && wifi up $radio"
    fi
    ;;
  state)
    hdr
    gen=$(cat "$D/generation" 2>/dev/null | tr -cd 'A-Za-z0-9-')
    if [ ! -f "$D/state.json" ]; then
      printf '{"nodes":[],"rules":[],"_generation":"%s"}' "${gen:-0}"
    elif [ -z "$gen" ] || grep -q "\"_generation\":\"$gen\"" "$D/state.json"; then
      cat "$D/state.json"
    else
      # Devices set up by the r1 first-boot script have state.json without the token, which
      # made every save fail. Report the router's current token so the page can save again.
      GEN="$gen" ruby -rjson -e 's = JSON.parse(File.read(ARGV[0])); s["_generation"] = ENV["GEN"]; print JSON.generate(s)' "$D/state.json" 2>/dev/null || cat "$D/state.json"
    fi
    ;;

  save_state)
    umask 077
    read_body "$D/state.tmp"
    if command -v jsonfilter >/dev/null 2>&1; then
      jsonfilter -i "$D/state.tmp" -e '@.nodes' >/dev/null 2>&1 || { rm -f "$D/state.tmp"; err "bad_json"; }
    fi
    # 若保存状态后连接断开，下次打开面板仍能从最新状态重新生成配置。
    touch "$D/draft-uncompiled" || err "save_failed"
    chmod 600 "$D/state.tmp" && mv "$D/state.tmp" "$D/state.json" || err "save_failed"
    ok ""
    ;;

  save_yaml)
    umask 077
    read_body "$D/panel.tmp"
    grep -q '^proxy-groups:' "$D/panel.tmp" || { rm -f "$D/panel.tmp"; err "bad_yaml"; }
    [ -f "$D/panel.yaml" ] && cp "$D/panel.yaml" "$D/backup/panel-$(date +%s).yaml"
    ls -t "$D"/backup/panel-*.yaml 2>/dev/null | tail -n +11 | while read -r f; do rm -f "$f"; done
    chmod 600 "$D/panel.tmp" && mv "$D/panel.tmp" "$D/panel.yaml" || err "save_failed"
    mkdir -p "$OC/config" || err "save_failed"
    cfg_tmp="$PANEL_CFG.tmp-$$"
    if ! cp "$D/panel.yaml" "$cfg_tmp" || ! mv -f "$cfg_tmp" "$PANEL_CFG"; then
      rm -f "$cfg_tmp"
      err "save_failed"
    fi
    rm -f "$D/draft-uncompiled"
    # 清理已删除订阅留下的缓存文件
    for f in "$OC"/proxy_provider/panel_*.yaml; do
      [ -f "$f" ] || continue
      grep -q "$(basename "$f")" "$D/panel.yaml" || rm -f "$f"
    done
    ok ""
    ;;

  apply) # 优先让内核热重载（几秒）；热重载不了才整套重启 OpenClash
    PANEL_DIR="$D" sh "$D/ipv4-only.sh" >/dev/null 2>&1 || err "ipv6_lock_failed"
    PANEL_DIR="$D" OC_DIR="$OC" ruby "$D/merge.rb" --install-hook >/dev/null 2>&1 || err "dns_hook_failed"
    cur=$(cfg_path)
    if [ ! -f "$D/orig_path" ] && [ "$cur" != "$PANEL_CFG" ]; then
      printf '%s' "$cur" > "$D/orig_path"
    fi
    if [ "$cur" = "$PANEL_CFG" ] && oc_running && [ -f "$OC/panel.yaml" ] && hot_reload; then
      ok ',"mode":"hot"'
    else
      uci set openclash.config.config_path="$PANEL_CFG"
      uci commit openclash
      if oc_enabled || oc_running; then
        later "/etc/init.d/openclash restart"
        ok ',"mode":"restart"'
      else
        ok ',"mode":"none"'
      fi
    fi
    ;;

  reset)
    [ "$BODYF" != "" ] && [ "$(cat "$BODYF")" = "RESET_PANEL_SETTINGS" ] || err "reset_confirmation_required"
    sh "$D/reset.sh"
    ;;

  pending) # 重新打开面板时，比较已保存配置和 OpenClash 实际加载的面板配置。
    pending=false
    if [ -e "$D/draft-uncompiled" ]; then
      pending=true
    elif [ -s "$PANEL_CFG" ]; then
      if [ "$(cfg_path)" != "$PANEL_CFG" ]; then
        pending=true
      elif oc_running && [ -s "$OC/panel.yaml" ]; then
        pending=$(OC_DIR="$OC" ruby "$D/merge.rb" "$PANEL_CFG" "$OC/panel.yaml" /dev/null compare 2>/dev/null) || err "pending_check_failed"
      fi
    fi
    hdr
    printf '{"pending":%s}' "$pending"
    ;;

  start)
    uci set openclash.config.enable=1; uci commit openclash
    later "/etc/init.d/openclash start"
    ok ""
    ;;

  stop)
    uci set openclash.config.enable=0; uci commit openclash
    later "/etc/init.d/openclash stop"
    ok ""
    ;;

  status)
    run=false; oc_running && run=true
    cur=$(cfg_path)
    panel=false; [ "$cur" = "$PANEL_CFG" ] && panel=true
    orig=false; [ -s "$D/orig_path" ] && orig=true
    rom=false; [ -f "${ROM_DIR:-/rom}/etc/clashpanel/api.sh" ] && rom=true
    hdr
    printf '{"running":%s,"panel":%s,"has_original":%s,"rom_panel":%s}' "$run" "$panel" "$orig" "$rom"
    ;;

  selfcheck) # 一键自检：只读检查，不修改设置；不输出密码、Wi-Fi 名称或订阅链接。
    items=''
    add() { [ -z "$items" ] || items="$items,"; items="$items{\"id\":\"$1\",\"level\":\"$2\",\"title\":\"$3\",\"detail\":\"$4\"}"; }
    gen=$(cat "$D/generation" 2>/dev/null | tr -cd 'A-Za-z0-9-')
    sgen=$(sed -n 's/.*"_generation":"\([A-Za-z0-9-]*\)".*/\1/p' "$D/state.json" 2>/dev/null | head -n 1)
    if [ -z "$gen" ] || [ "$gen" = 0 ] || [ "$gen" = "$sgen" ]; then
      add save ok '设置可以保存' '订阅、节点和其他设置能正常保存。'
    else
      add save warn '设置记录已自动修复' '这台路由器用旧固件初始化过。面板已自动修正，随便保存一次设置后就恢复正常；建议以后升级到最新固件。'
    fi
    lines=1
    if [ ! -f "$D/state.json" ] || { grep -q '"nodes":\[\]' "$D/state.json" && ! grep -q '"subs":\[[^]]' "$D/state.json"; }; then lines=0; fi
    if oc_running; then
      add proxy ok '代理正在运行' '一切正常。'
    elif [ "$lines" = 0 ]; then
      add proxy warn '代理还没有启动' '首次使用：先在「线路」导入节点或订阅，点「应用」，再点「启动代理」。'
    else
      add proxy warn '代理还没有启动' '已经有线路，请点「启动代理」。'
    fi
    if oc_enabled && ! ls "${RC_DIR:-/etc/rc.d}"/S*openclash >/dev/null 2>&1; then
      add autostart warn '重启后不会自动启动代理' '路由器重启后，需要再点一次「启动代理」。'
    fi
    if [ -e "$D/draft-uncompiled" ]; then add pending warn '有设置还没生效' '请点「应用」。'; fi
    open=0
    for s in $(uci -q show wireless | sed -n 's/^wireless\.\([A-Za-z0-9_]*\)=wifi-iface$/\1/p'); do
      [ "$(uci -q get "wireless.$s.mode")" = ap ] || continue
      [ "$(uci -q get "wireless.$s.disabled")" = 1 ] && continue
      radio=$(uci -q get "wireless.$s.device")
      [ -n "$radio" ] && [ "$(uci -q get "wireless.$radio.disabled")" = 1 ] && continue
      enc=$(uci -q get "wireless.$s.encryption")
      case "$enc" in ''|none|owe*) open=$((open + 1));; *) [ -n "$(uci -q get "wireless.$s.key")" ] || open=$((open + 1));; esac
    done
    if [ "$open" -gt 0 ]; then
      add wifi fail 'Wi-Fi 没有密码' "有 $open 个已开启的 Wi-Fi 是开放网络，任何人都能连接。请设置密码。"
    else
      add wifi ok 'Wi-Fi 已加密' '已开启的 Wi-Fi 都设置了密码。'
    fi
    if [ -f "${MYWIFI:-/sbin/mywifi}" ] && [ "$(uci -q get system.@status[0].wifi)" != 1 ] && [ "$(uci -q get base_config.@status[0].wifi)" != 1 ]; then
      add wifimark warn 'Wi-Fi 可能被系统重置' '系统自带的 Wi-Fi 初始化脚本仍可能运行，并把 Wi-Fi 改成无密码。'
    fi
    if [ "$(uci -q get upnpd.settings.enabled)" = 1 ] || [ "$(uci -q get upnpd.config.enabled)" = 1 ]; then
      add upnp warn '自动开端口（UPnP）已开启' '家里的设备可以自己在路由器上开端口，存在安全隐患。不需要时建议关闭。'
    fi
    if [ "$(cat "${PROC_DIR:-/proc}/sys/net/ipv6/conf/all/disable_ipv6" 2>/dev/null)" != 1 ] || [ "$(uci -q get openclash.config.ipv6_enable)" = 1 ]; then
      add ipv6 warn 'IPv6 没有完全关闭' '部分访问可能绕过代理。点一次「应用」会自动关好。'
    fi
    if ! grep -q 'BEGIN CLASHPANEL FIXED DNS' "$OC/custom/openclash_custom_overwrite.sh" 2>/dev/null; then
      add dnshook warn 'DNS 保护还没安装' '点一次「应用」会自动安装。'
    fi
    if [ "$(uci -q get dhcp.lan.ignore)" = 1 ]; then add dhcp warn '局域网 DHCP 已关闭' '新设备连上后可能拿不到 IP 地址。'; fi
    if grep -q -E 'failed|timed out|wrong board' "${FIRSTBOOT_LOG:-/tmp/routelite-firstboot.log}" 2>/dev/null; then
      add firstboot warn '首次开机初始化有报错' '请把路由器 /tmp/routelite-firstboot.log 的内容发给维护者。'
    fi
    free=$(df -k "${OVERLAY_DIR:-/overlay}" 2>/dev/null | awk 'NR==2 {print $4}')
    case "$free" in ''|*[!0-9]*) ;; *) if [ "$free" -lt 10240 ]; then add storage warn '存储空间不足' "可写空间只剩 $((free / 1024)) MB。"; fi;; esac
    mem=$(awk '/^MemAvailable:/ {print $2}' "${PROC_DIR:-/proc}/meminfo" 2>/dev/null)
    case "$mem" in ''|*[!0-9]*) ;; *) if [ "$mem" -lt 30720 ]; then add memory warn '可用内存偏低' "可用内存约 $((mem / 1024)) MB，线路多时可能变慢。"; fi;; esac
    if [ -f "${ROM_DIR:-/rom}/etc/clashpanel/api.sh" ]; then
      add rom ok '面板已内置在固件里' '按 RESET 后面板会自动恢复，但节点、订阅和设置会被清空。'
    else
      add rom warn '固件没有内置面板' '按 RESET 会清除面板和全部设置，请勿按 RESET。'
    fi
    worst=ok
    case "$items" in *'"level":"warn"'*) worst=warn;; esac
    case "$items" in *'"level":"fail"'*) worst=fail;; esac
    hdr
    printf '{"ok":true,"level":"%s","items":[%s]}' "$worst" "$items"
    ;;






  devices) # 局域网设备：来自路由器的 DHCP 租约
    hdr
    printf '['
    first=1
    if [ -f "${LEASES:-/tmp/dhcp.leases}" ]; then
      while read -r _exp mac ip name _rest; do
        ip=$(printf '%s' "$ip" | tr -cd '0-9.')
        mac=$(printf '%s' "$mac" | tr -cd '0-9a-fA-F:')
        name=$(printf '%s' "$name" | tr -cd 'A-Za-z0-9._ -')
        [ "$name" = "*" ] && name=""
        [ -n "$ip" ] || continue
        [ "$first" = 1 ] || printf ','
        first=0
        printf '{"ip":"%s","mac":"%s","name":"%s"}' "$ip" "$mac" "$name"
      done < "${LEASES:-/tmp/dhcp.leases}"
    fi
    printf ']'
    ;;

  dns_get) # 只读实际运行配置；不显示节点凭据或业务规则。
    hdr
    ipv6_disabled=false
    if [ "$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6 2>/dev/null)" = 1 ] && [ "$(cat /proc/sys/net/ipv6/conf/default/disable_ipv6 2>/dev/null)" = 1 ] && [ "$(cat /proc/sys/net/ipv6/conf/all/forwarding 2>/dev/null)" = 0 ] && [ "$(uci -q get openclash.config.ipv6_enable)" = 0 ] && [ "$(uci -q get openclash.config.ipv6_dns)" = 0 ]; then ipv6_disabled=true; fi
    ruby -ryaml -e '
      dns = YAML.load_file(ARGV[0]).fetch("dns", {})
      # Recognize both the previous single resolver and current redundant pair.
      hidden = [
        ["https://8.8.8.8/dns-query#PROXY"],
        ["https://8.8.8.8/dns-query#PROXY", "https://1.1.1.1/dns-query#PROXY"]
      ].include?(dns["nameserver"])
      initial = dns["nameserver"] == ["udp://223.5.5.5:53#DIRECT", "udp://119.29.29.29:53#DIRECT"]
      expected = (hidden || initial) && !dns.key?("fallback") && dns["nameserver-policy"].is_a?(Hash)
      puts %Q({"locked":true,"hidden":#{hidden},"policy_active":#{expected},"fake_ip":#{dns["enhanced-mode"] == "fake-ip"},"ipv6":#{!!dns["ipv6"]},"ipv6_disabled":#{ARGV[1] == "true"},"china_default":#{dns.fetch("nameserver-policy", {}).key?("geosite:cn")}})
    ' "$OC/panel.yaml" "$ipv6_disabled" 2>/dev/null || printf '{"locked":true,"policy_active":false}'
    ;;

  dns_set|dns_reset)
    err "dns_policy_locked"
    ;;

  secret) # 给已登录的面板用：浏览器用它直连 OpenClash 的 API
    hdr; printf '{"secret":"%s","port":"%s"}' "$(secret | tr -cd 'A-Za-z0-9._-')" "$(cnport)"
    ;;

  ip) # 出口 IP：走 OpenClash 的 HTTP 代理端口去查；另附路由器直连的 IP 做对比
    hp=$(uci -q get openclash.config.http_port); hp=${hp:-7890}
    via=; proxy_error=
    if oc_running; then
      config=$(cfg_path)
      if [ -n "$config" ] && credentials=$(proxy_curl_config "$OC/${config##*/}"); then
        for target in https://api.ipify.org https://ipv4.icanhazip.com; do
          curl_ok=1
          response=$(printf '%s\n' "$credentials" | curl -q --config - --noproxy '' -s -m 7 \
            -x "http://127.0.0.1:$hp" -w '\n%{http_connect} %{http_code}\n' "$target" 2>/dev/null) || curl_ok=0
          codes=$(printf '%s\n' "$response" | tail -n 1)
          case "$codes" in
            '407 '*|*' 407') proxy_error=auth; break ;;
            '200 200') ;;
            *) continue ;;
          esac
          [ "$curl_ok" = 1 ] || continue
          via=$(printf '%s\n' "$response" | sed '$d' | ipv4_response)
          [ -z "$via" ] || break
        done
      fi
    fi
    direct=$(curl -q --noproxy '*' -fsS -m 6 http://ip.3322.net 2>/dev/null | ipv4_response)
    hdr
    printf '{"proxy_ip":"%s","direct_ip":"%s","proxy_error":"%s"}' "$via" "$direct" "$proxy_error"
    ;;

  *)
    err "unknown_action"
    ;;
esac
